# vlsi-verification-automation

A working, mock-backed reference implementation of three connected verification-infrastructure components:

1. **Execution wrappers** for formal tools (Cadence-/Synopsys-style adapters) with timeout, return-code classification, log parsing, retries
2. **Bayesian Optimization** (GP + constrained Expected Improvement) that proposes stimulus vectors and learns from simulation scores
3. **CI + license monitoring** for 50+ concurrent jobs (FIFO seat gate, utilization / wait / peak metrics)

> **Honesty note.** No proprietary tool is required or emulated faithfully. `mock_eda/` is a *mock* with injectable failures; `simulation/synthetic_dut.py` is a *synthetic* model.
> All numbers in `reports/` are **measured on those mocks**, and demonstrate method, not vendor performance. Real-tool syntax is left as `<placeholders>`.

## Quick start
```bash
pip install -r requirements.txt
make test              # 72 tests, ~25 s
make demo-bo           # BO vs constrained-random on the synthetic DUT (~90 s)
make bench-throughput  # A/B + ablation on the mock formal tool
make bench-license     # 60 requests vs 20 seats
make pipeline          # full CI pipeline locally -> reports/ci_summary.md
```

## Read this first
- `docs/PROJECT_GUIDE.md`: the 14-section explanation (architecture, wrappers line-by-line, throughput methodology, BO from first principles, CI, licenses, concurrency, testing, benchmark honesty, resume validation)
- `docs/INTERVIEW_QA.md`: 20 questions with short/detailed/project/follow-up answers

## Map: your prompt → code
| Prompt section | Where |
|---|---|
| 3 Wrappers | `wrappers/`, `configs/tools.yaml`, `parsers/`, `mock_eda/` |
| 4 Throughput | `benchmarks/metrics.py`, `benchmarks/throughput_bench.py` |
| 5 Bayesian Optimization | `optimization/bayes_opt.py`, `stimulus/space.py` |
| 6 Corner cases | `stimulus/scoring.py`, `simulation/synthetic_dut.py`, `optimization/run_demo.py` |
| 7 CI | `ci/run_pipeline.py`, `.github/`, `.gitlab-ci.yml`, `ci/Jenkinsfile` |
| 8 Licenses | `license_monitor/`, `benchmarks/license_bench.py` |
| 9 Concurrency | `wrappers/job_runner.py` |
| 11 Testing | `tests/` |

## Using it with real tools (summary)
Edit `configs/tools.yaml` (command template, env, return-code map, license feature) → add golden logs + regexes to `parsers/` → set seats in `configs/licenses.yaml` →
set `LICENSE_STATUS_COMMAND` in `license_monitor/server_poller.py` → replace `simulation/synthetic_dut.py::simulate` with your simulator launcher + coverage/assertion parser.
