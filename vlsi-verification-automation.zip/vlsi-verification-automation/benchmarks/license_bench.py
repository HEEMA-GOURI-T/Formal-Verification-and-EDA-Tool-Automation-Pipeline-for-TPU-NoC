"""60-job simulation load against a 20-seat FIFO license pool (60 > 50 concurrent requests).
Jobs are sleeps (stand-ins for simulator runs) so the benchmark isolates license behaviour."""
import json
import os
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from license_monitor.license_pool import LicensePool
from license_monitor.metrics import compute_license_metrics
from license_monitor.report import write_reports
from wrappers.config import REPO


def run(n_jobs=60, seats=20, workers=60, hold=(0.05, 0.25), seed=1, gate=True, label=""):
    rnd = random.Random(seed)
    holds = [rnd.uniform(*hold) for _ in range(n_jobs)]
    pool = LicensePool({"MOCK_SIM": seats})
    peak = {"threads": 0}
    live = [0]; lock = threading.Lock()

    def job(i):
        with lock:
            live[0] += 1; peak["threads"] = max(peak["threads"], live[0])
        with pool.lease("MOCK_SIM", f"j{i}"):
            time.sleep(holds[i])
        with lock:
            live[0] -= 1
    t0 = time.monotonic()
    with ThreadPoolExecutor(workers) as ex:
        list(ex.map(job, range(n_jobs)))
    m = compute_license_metrics(pool.events, {"MOCK_SIM": seats})
    m["MOCK_SIM"]["makespan_s"] = round(time.monotonic() - t0, 3)
    m["MOCK_SIM"]["peak_threads"] = peak["threads"]
    return m, pool


def main():
    m, pool = run()
    out = os.path.join(REPO, "reports")
    write_reports(m, out, "license_report")
    print(json.dumps(m, indent=2))


if __name__ == "__main__":
    main()
