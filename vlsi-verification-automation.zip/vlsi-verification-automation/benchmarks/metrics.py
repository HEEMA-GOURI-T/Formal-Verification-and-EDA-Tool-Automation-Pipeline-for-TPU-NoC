"""Metric collection for throughput benchmarking (works for mock AND real runs)."""
import os
import statistics
import time
from dataclasses import dataclass, asdict
from typing import Dict, List


@dataclass
class RegressionMetrics:
    label: str
    wall_s: float
    properties_total: int
    properties_conclusive: int          # proven + cex (undetermined = wasted effort)
    jobs: int
    jobs_failed: int
    retries: int
    cpu_s: float                        # user+sys of children
    workers: int

    @property
    def throughput_props_per_hour(self): return 3600 * self.properties_total / self.wall_s
    @property
    def conclusive_per_hour(self): return 3600 * self.properties_conclusive / self.wall_s
    @property
    def cpu_utilization_pct(self): return 100 * self.cpu_s / (self.wall_s * self.workers)

    def as_dict(self):
        d = asdict(self)
        d.update(throughput_props_per_hour=round(self.throughput_props_per_hour, 1),
                 conclusive_per_hour=round(self.conclusive_per_hour, 1),
                 cpu_utilization_pct=round(self.cpu_utilization_pct, 2))
        return d


class CpuProbe:
    """Child-process CPU time via os.times(): children_user+children_system deltas."""
    def __enter__(self):
        t = os.times(); self._c0 = t.children_user + t.children_system; self._w0 = time.monotonic(); return self

    def __exit__(self, *a):
        t = os.times(); self.cpu_s = t.children_user + t.children_system - self._c0
        self.wall_s = time.monotonic() - self._w0


def collect(label, results: Dict, stats, probe: CpuProbe, workers: int) -> RegressionMetrics:
    ok = [r for r in results.values() if r.ok]
    total = sum(r.summary.get("total", 0) for r in ok)
    concl = sum(r.summary.get("proven", 0) + r.summary.get("cex", 0) for r in ok)
    return RegressionMetrics(label, probe.wall_s, total, concl, len(results),
                             sum(not r.ok for r in results.values()), stats.retries, probe.cpu_s, workers)


def median_of(runs: List[RegressionMetrics]) -> RegressionMetrics:
    runs = sorted(runs, key=lambda r: r.wall_s)
    return runs[len(runs) // 2]


def pct_improvement(before, after, higher_is_better=True):
    if before == 0: return float("nan")
    d = (after - before) / before * 100
    return round(d if higher_is_better else -d, 1)
