"""A/B/ablation benchmark of the regression strategy on the MOCK formal tool.

Baseline  : one tool invocation per property, no elaboration cache, random order, 4 workers
Optimized : properties batched per invocation, elaboration cache, LPT scheduling, license-sized pool
The numbers printed are MEASURED on the mock (whose overheads are parameters), so they show the
*methodology* and the relative effect of each technique - not what real Cadence/Synopsys give.
"""
import json
import os
import random
import re
import shutil
import sys
import tempfile
from typing import List

from benchmarks.metrics import CpuProbe, collect, median_of, pct_improvement
from license_monitor.license_pool import LicensePool
from wrappers.config import REPO, load_tools_config
from wrappers.formal_wrapper import Status
from wrappers.job_runner import Job, JobRunner

PROP_RE = re.compile(r"^\s*(\w+)\s*:\s*assert\s+property\b.*?//\s*cx=(\d+)")


def load_props(path):
    return [(m.group(1), int(m.group(2)), line) for line in open(path) if (m := PROP_RE.match(line))]


def write_jobs(props, batch, outdir, tool, design, order, cache_key):
    """Split properties into batches, write one assertion file per batch -> Job list."""
    props = list(props)
    if order == "lpt":
        props.sort(key=lambda p: -p[1])
    batches = [props[i:i + batch] for i in range(0, len(props), batch)]
    jobs = []
    for i, b in enumerate(batches):
        f = os.path.join(outdir, f"{cache_key}_b{i}.sv")
        open(f, "w").write("".join(p[2] for p in b))
        jobs.append(Job(id=f"{cache_key}_b{i}", tool=tool, design=design, assertions=f, seed=1,
                        est_cost=sum(p[1] for p in b) + 8))
    return jobs


def run_variant(label, cfg, props, tool, design, tmp, *, batch, cache, workers, order, repeat):
    runs = []
    for r in range(repeat):
        shutil.rmtree(os.path.join(tmp, "cache"), ignore_errors=True)       # cold cache each repeat
        jobs = write_jobs(props, batch, tmp, tool, design, order, f"{label}_{r}")
        if order == "random":
            random.Random(r).shuffle(jobs)
        runner = JobRunner(cfg, max_workers=workers, retries=1, backoff_s=0.05)
        cache_dir = os.path.join(tmp, "cache") if cache else None

        def run_fn(*a, **kw):
            from wrappers.formal_wrapper import run_formal
            # un-cached variant gets a fresh cache dir per job => always a cold elaboration
            kw["cache_dir"] = cache_dir or tempfile.mkdtemp(dir=tmp)
            return run_formal(*a, **kw)
        runner.run_fn = run_fn
        with CpuProbe() as probe:
            res = runner.run(jobs)
        runs.append(collect(label, res, runner.stats, probe, workers))
    return median_of(runs)


def main(repeat=3, n_props=48):
    cfg = load_tools_config(os.path.join(REPO, "configs/tools.yaml"))
    props = load_props(os.path.join(REPO, "assertions/fifo_props.sv"))[:n_props]
    design = os.path.join(REPO, "formal/rtl/sync_fifo.sv")
    tool = "cadence_mock"
    tmp = tempfile.mkdtemp(prefix="bench_")
    variants = [
        ("baseline",          dict(batch=1,  cache=False, workers=4, order="random")),
        ("+batching",         dict(batch=8,  cache=False, workers=4, order="random")),
        ("+elab_cache",       dict(batch=8,  cache=True,  workers=4, order="random")),
        ("+lpt_scheduling",   dict(batch=8,  cache=True,  workers=4, order="lpt")),
        ("optimized(+8wkrs)", dict(batch=8,  cache=True,  workers=8, order="lpt")),
    ]
    out = {}
    for name, kw in variants:
        m = run_variant(name, cfg, props, tool, design, tmp, repeat=repeat, **kw)
        out[name] = m.as_dict()
        print(f"{name:20s} wall={m.wall_s:6.2f}s  props/h={m.throughput_props_per_hour:10.0f}  "
              f"cpu_util={m.cpu_utilization_pct:5.1f}%  failed={m.jobs_failed}", flush=True)
    b, o = out["baseline"], out["optimized(+8wkrs)"]
    summary = {
        "assertion_throughput_props_per_hour": (b["throughput_props_per_hour"], o["throughput_props_per_hour"],
                                                pct_improvement(b["throughput_props_per_hour"], o["throughput_props_per_hour"])),
        "regression_runtime_s": (round(b["wall_s"], 2), round(o["wall_s"], 2),
                                 pct_improvement(b["wall_s"], o["wall_s"], higher_is_better=False)),
        "conclusive_props_per_hour": (b["conclusive_per_hour"], o["conclusive_per_hour"],
                                      pct_improvement(b["conclusive_per_hour"], o["conclusive_per_hour"])),
        "failed_jobs": (b["jobs_failed"], o["jobs_failed"], None),
    }
    os.makedirs(os.path.join(REPO, "reports"), exist_ok=True)
    json.dump({"variants": out, "summary": summary, "n_props": len(props), "repeat": repeat,
               "note": "MEASURED ON MOCK TOOL. Overheads are mock parameters, not vendor numbers."},
              open(os.path.join(REPO, "reports/throughput_bench.json"), "w"), indent=2)
    lines = ["# Throughput benchmark (mock tool)", "",
             "| variant | wall s | props/hour | cpu util % | jobs | failed |", "|---|---|---|---|---|---|"]
    for k, v in out.items():
        lines.append(f"| {k} | {v['wall_s']:.2f} | {v['throughput_props_per_hour']:.0f} | {v['cpu_utilization_pct']} | {v['jobs']} | {v['jobs_failed']} |")
    lines += ["", "| metric | before | after | improvement % |", "|---|---|---|---|"]
    for k, (bf, af, imp) in summary.items():
        lines.append(f"| {k} | {bf} | {af} | {imp if imp is not None else '-'} |")
    open(os.path.join(REPO, "reports/throughput_bench.md"), "w").write("\n".join(lines) + "\n")
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main(*(int(a) for a in sys.argv[1:]))
