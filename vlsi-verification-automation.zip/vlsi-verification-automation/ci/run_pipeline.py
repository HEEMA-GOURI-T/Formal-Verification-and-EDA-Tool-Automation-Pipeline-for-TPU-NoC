"""Local/CI pipeline driver. Same script runs under Jenkins, GitLab CI, GitHub Actions or a shell.

Stages: validate -> elaborate -> formal -> simulate -> assertion_analysis -> coverage -> license -> report
Exit code != 0 on any gate failure. Writes reports/ci_summary.{json,md} (machine + human).
"""
import json
import logging
import os
import sys
import tempfile
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from benchmarks.throughput_bench import load_props, write_jobs
from license_monitor.license_pool import LicensePool
from license_monitor.metrics import compute_license_metrics
from license_monitor.report import write_reports
from optimization.objective import make_objective
from simulation.synthetic_dut import simulate
from stimulus.generators import ConstrainedRandom
from stimulus.scoring import CoverageLedger
from stimulus.space import SearchSpace
from wrappers.config import REPO, load_tools_config
from wrappers.formal_wrapper import run_formal
from wrappers.job_runner import JobRunner
import yaml

log = logging.getLogger("ci")
REPORTS = os.path.join(REPO, "reports")
BASELINE = os.path.join(REPO, "ci/baseline_cex.json")


class Gate(Exception):
    pass


class Ctx:
    def __init__(self, tool="cadence_mock", sim_jobs=50, workers=8):
        self.cfg = load_tools_config(os.path.join(REPO, "configs/tools.yaml"))
        self.lic = yaml.safe_load(open(os.path.join(REPO, "configs/licenses.yaml")))
        self.reg = yaml.safe_load(open(os.path.join(REPO, "configs/regression.yaml")))
        self.tool, self.sim_jobs, self.workers = tool, sim_jobs, workers
        self.pool = LicensePool({k: v for k, v in self.lic["features"].items()})
        self.design = os.path.join(REPO, "formal/rtl/sync_fifo.sv")
        self.assertions = os.path.join(REPO, "assertions/fifo_props.sv")
        self.tmp = tempfile.mkdtemp(prefix="ci_")
        self.data = {}


def st_validate(c: Ctx):
    assert c.cfg.tools, "no tools"
    assert os.path.exists(c.design) and os.path.exists(c.assertions)
    SearchSpace.from_yaml(os.path.join(REPO, "configs/bo_search_space.yaml"))
    return {"tools": sorted(c.cfg.tools)}


def st_elaborate(c: Ctx):
    first = load_props(c.assertions)[:1]
    f = os.path.join(c.tmp, "elab_probe.sv"); open(f, "w").write(first[0][2])
    r = run_formal(c.tool, c.design, f, c.cfg, 30)
    if not r.ok:
        raise Gate(f"elaboration probe failed: {r.status.value} {r.message}")
    return {"elab_s": round(r.runtime_s, 3)}


def st_formal(c: Ctx):
    props = load_props(c.assertions)
    jobs = write_jobs(props, c.reg["batch_size"], c.tmp, c.tool, c.design, "lpt", "ci")
    runner = JobRunner(c.cfg, max_workers=c.workers, retries=c.reg["retries"], backoff_s=c.reg["backoff_s"],
                       license_pool=c.pool, license_wait_s=120)
    res = runner.run(jobs)
    if runner.stats.failed:
        bad = {k: v.status.value for k, v in res.items() if not v.ok}
        raise Gate(f"{runner.stats.failed} formal job(s) failed infrastructure-wise: {bad}")
    merged = {}
    for r in res.values():
        merged.update(r.properties)
    c.data["formal"] = merged
    return {"jobs": len(jobs), "retries": runner.stats.retries, "wall_s": round(runner.stats.wall_s, 2),
            "properties": len(merged)}


def st_simulate(c: Ctx):
    space = SearchSpace.from_yaml(os.path.join(REPO, "configs/bo_search_space.yaml"))
    stim = ConstrainedRandom(space, seed=2024).next(c.sim_jobs)
    metrics = [None] * len(stim)

    def one(i):
        with c.pool.lease("MOCK_SIM", f"sim{i}", timeout=120):
            metrics[i] = simulate(space.decode(stim[i]), seed=i)
    with ThreadPoolExecutor(max_workers=c.sim_jobs) as ex:     # 50 concurrent *requests*; seats throttle them
        list(ex.map(one, range(len(stim))))
    c.data["sim"] = metrics
    return {"sims": len(metrics)}


def st_assertions(c: Ctx):
    """Gate on NEW counterexamples vs a stored baseline (so known/waived cex don't block merges)."""
    path = BASELINE
    cex = sorted(k for k, v in c.data["formal"].items() if v == "cex")
    if not os.path.exists(path):
        json.dump(cex, open(path, "w"), indent=1)
        return {"cex": len(cex), "baseline": "created"}
    new = sorted(set(cex) - set(json.load(open(path))))
    if new:
        raise Gate(f"new counterexamples vs baseline: {new}")
    sim_fail = sum(1 for m in c.data["sim"] if m.overflow_count)
    undetermined = sum(1 for v in c.data["formal"].values() if v == "undetermined")
    return {"cex": len(cex), "new_cex": 0, "undetermined": undetermined, "sim_runs_with_overflow": sim_fail}


def st_coverage(c: Ctx):
    led = CoverageLedger()
    for m in c.data["sim"]:
        led.update(m)
    from simulation.synthetic_dut import ALL_BINS
    pct = 100 * len(led.bins & set(ALL_BINS)) / len(ALL_BINS)
    if pct < 50:
        raise Gate(f"functional coverage {pct:.1f}% below 50% gate")
    return {"functional_cov_pct": round(pct, 1)}


def st_license(c: Ctx):
    m = compute_license_metrics(c.pool.events, c.pool.seats)
    write_reports(m, REPORTS, "ci_license_report")
    sim = m["MOCK_SIM"]
    if sim["timeouts"]:
        raise Gate(f"{sim['timeouts']} license timeouts")
    return {"MOCK_SIM_peak_concurrency": sim["peak_concurrency"], "MOCK_SIM_util_pct": sim["utilization_pct"],
            "MOCK_SIM_p95_wait_s": sim["p95_wait_s"]}


STAGES = [("validate", st_validate), ("elaborate", st_elaborate), ("formal", st_formal),
          ("simulate", st_simulate), ("assertion_analysis", st_assertions), ("coverage", st_coverage),
          ("license_monitor", st_license)]


def main(argv=None):
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    c = Ctx()
    rows, failed = [], False
    for name, fn in STAGES:
        t0 = time.monotonic()
        try:
            detail = fn(c); status = "PASS"
        except Gate as g:
            detail, status, failed = {"error": str(g)}, "FAIL", True
        except Exception as e:
            detail, status, failed = {"error": repr(e), "trace": traceback.format_exc()[-400:]}, "ERROR", True
        rows.append({"stage": name, "status": status, "seconds": round(time.monotonic() - t0, 2), **detail})
        print(f"[{status:5s}] {name:20s} {rows[-1]['seconds']:6.2f}s  {detail}")
        if failed:
            break
    os.makedirs(REPORTS, exist_ok=True)
    json.dump(rows, open(os.path.join(REPORTS, "ci_summary.json"), "w"), indent=2)
    md = ["# CI summary", "", "| stage | status | seconds | detail |", "|---|---|---|---|"]
    for r in rows:
        d = {k: v for k, v in r.items() if k not in ("stage", "status", "seconds", "trace")}
        md.append(f"| {r['stage']} | {r['status']} | {r['seconds']} | {d} |")
    open(os.path.join(REPORTS, "ci_summary.md"), "w").write("\n".join(md) + "\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
