# Interview Q&A

Format per question: **Short** (≈30 s) · **Detailed** · **In this project** · **Follow-up**.
Speak in terms of *your* real work where it differs; the repo is the model implementation.

---
## Beginner

### 1. What is formal verification?
**Short:** Using mathematical engines to prove a design satisfies properties for *all* legal inputs, or to produce a counterexample.
**Detailed:** Properties (SVA assertions, assumptions, cover) are compiled with the RTL into a model; engines (BMC, induction/k-induction, interpolation/IC3-style) either prove, find a cex trace, or time out (*undetermined*/bounded proof). Assumptions constrain inputs, so *over-constraining* hides bugs and *under-constraining* gives false failures.
**Project:** Properties in `assertions/fifo_props.sv`; wrapper returns `proven/cex/undetermined` per property.
**Follow-up:** What does a bounded proof of depth 20 mean? (No violation within 20 cycles; not a full proof.)

### 2. What is an assertion?
**Short:** An executable statement of expected behaviour, e.g. "after write, FIFO is not empty."
**Detailed:** SVA immediate (`assert (cond)`) and concurrent (`assert property (@(posedge clk) a |-> ##[1:3] b)`) assertions; the same property can be checked in simulation (dynamic) or proven (formal). Assumptions (`assume`) constrain inputs; `cover` shows reachability.
**Project:** `no_overflow`, `no_underflow`, … in `assertions/fifo_props.sv`.
**Follow-up:** What is vacuous success? (Antecedent never true, so the assertion passes meaninglessly; check with cover.)

### 3. What is an execution wrapper?
**Short:** A program that runs an EDA tool safely and returns structured results.
**Detailed:** Command construction from templates, clean env, timeout with process-group kill, log capture, return-code classification, parsing, retry hooks, never raising for tool-side failure.
**Project:** `wrappers/formal_wrapper.py::run_formal` returning `FormalResult(status, returncode, runtime, properties, summary, logfile)`.
**Follow-up:** Why argv lists instead of shell strings? (No quoting/injection bugs; paths with spaces are safe.)

---
## Intermediate

### 4. Why Python?
**Short:** Fast to build glue: subprocess control, parsing, stats/ML libraries, CI-friendly.
**Detailed:** The heavy compute is in the EDA tool; Python orchestrates. Rich ecosystem (scikit-learn/scipy/numpy, pytest, YAML). Tcl remains the control language *inside* tools; Python wraps around it. Weak spots: raw speed (irrelevant here), packaging in locked-down farms (pin versions/containers).
**Project:** Entire repo; threads for orchestration, sklearn for GP.
**Follow-up:** When would you not use Python? (Latency-critical schedulers handling 10⁵ events/s, or inside simulators where C/DPI is needed.)

### 5. Why Bayesian Optimization?
**Short:** Each simulation is expensive; BO chooses the next test using a model of past results, so it needs fewer runs than random search.
**Detailed:** BO suits ≤~20 continuous/ordinal knobs, expensive noisy objectives, and constraints. Alternatives: grid/random (inefficient), genetic algorithms (many evaluations), RL (needs lots of data), coverage-directed ML/classifiers (need labelled history). BO also gives uncertainty and interpretable length-scales.
**Project:** `optimization/bayes_opt.py`; measured on synthetic DUT: ~39 failing stimuli vs 2.5 in 60 evaluations, and first failure after 12.5 vs 20 evaluations (median).
**Follow-up:** When does BO fail? (Flat/needle objectives, very high dimension, categorical sequence structure, heavy noise.)

### 6. How did you improve throughput?
**Short:** Found where wall time went, then removed overhead: batching properties per session, caching elaboration, scheduling longest jobs first, sizing the pool to seats.
**Detailed:** Profile first (startup/elab vs solve time vs idle tail). Change one thing at a time with ablation. Track *conclusive* throughput so you don't "win" by timing out more.
**Project:** `benchmarks/throughput_bench.py` ablation (mock): batching is the largest lever; more workers than jobs helps nothing.
**Follow-up:** What if batching increases memory? (Cap batch size by RAM per session; group by cone of influence.)

### 7. How did you handle parallel simulations?
**Short:** A bounded thread pool launching subprocesses, gated by a fair license pool, with retries on transient failures.
**Detailed:** Threads wait on child processes; the license gate ensures we never request more seats than owned and queues FIFO; timeouts kill process groups; failures isolated per job.
**Project:** `JobRunner` + `LicensePool`; `ci/run_pipeline.py::st_simulate` submits 50 concurrent requests.
**Follow-up:** Why not multiprocessing? (Work isn't CPU-bound in Python; processes add IPC cost.)

---
## Advanced

### 8. How did you measure the 25% improvement?
**Short:** Same benchmark set, same tool version, repeated runs, baseline vs candidate, median of conclusive properties per hour.
**Detailed:** Define the metric, freeze inputs, cold caches, interleave runs, ≥5 repeats, report median and spread, ablate each technique, check undetermined % didn't rise. Keep scripts and logs as evidence.
**Project:** `benchmarks/metrics.py`, `throughput_bench.py` (mock numbers are for method only).
**Follow-up:** How do you know the gain isn't noise? (Compare spread across repeats; use a paired comparison/bootstrap CI.)

### 9. How did BO select stimuli?
**Short:** Fit a GP to (stimulus → score), then pick the point with the highest constrained Expected Improvement.
**Detailed:** Initial random legal points → fit GP (and one per constraint) → sample ~2k legal candidates (Sobol + local around best) → acquisition = EI × P(feasible) → run → refit. Batch via kriging believer for parallel sims.
**Project:** `_candidates`, `_acquire`, `run` in `bayes_opt.py`.
**Follow-up:** How do you handle integer knobs? (Round and *snap* the encoded point so the GP sees what actually ran.)

### 10. What acquisition function did you use?
**Short:** Expected Improvement, multiplied by probability of satisfying cost/memory constraints.
**Detailed:** `EI=(μ−f*−ξ)Φ(z)+σφ(z)`, ξ=0.01. Alternatives: UCB (`μ+κσ`, simple, tunable exploration), Thompson sampling (natural for batches), Knowledge Gradient (costly), PI (too greedy). EI is parameter-light and robust.
**Project:** `expected_improvement` + `_acquire`.
**Follow-up:** Why multiply by P(feasible)? (Expected improvement *given* the result will be usable.)

### 11. How did you avoid license starvation?
**Short:** FIFO ticket queue per feature, bounded waits, retry with backoff, and priority classes in production.
**Detailed:** Without ordering, a stream of short jobs can repeatedly win seats over a long job. Ticketing guarantees the head waiter is next. Also cap exploratory work (BO) so it can't consume all seats during release crunches.
**Project:** `LicensePool.acquire` (deque per feature; `test_fifo_fairness_no_starvation`).
**Follow-up:** What about other users on the same server? (Poll server status; adapt pool size to observed availability.)

### 12. How did you handle failed tool runs?
**Short:** Classify precisely, retry only transient classes, never treat rc=0-without-results as success.
**Detailed:** `TIMEOUT`, `CRASH`, `LICENSE_UNAVAILABLE`, `TOOL_ERROR`, `PARSE_ERROR`, `LAUNCH_ERROR`. Retry crash/license with exponential backoff; don't retry deterministic failures. Preserve logs for triage; surface failures in CI.
**Project:** `Status` enum, `JobRunner.retry_on`, tests for each class.
**Follow-up:** How do you detect flaky tools? (Track per-tool crash rate per version; quarantine.)

### 13. How would you scale from 50 to 500 jobs?
**Short:** Move from one launcher host to a farm scheduler, keep the same job/wrapper contract, add resource-aware scheduling and central metrics.
**Detailed:** Submit via LSF/Slurm/SGE (or Kubernetes with a license-aware admission controller); license tokens as scheduler resources; shard results in object storage; metrics into Prometheus/ELK; back-pressure on the optimizer; large-batch BO or TuRBO; idempotent jobs for safe requeue.
**Project:** `run_fn` is injectable in `JobRunner`, so "run locally" can become "submit and wait".
**Follow-up:** Where does the first bottleneck appear? (License seats and shared storage I/O before CPU.)

### 14. What happens if the formal solver times out?
**Short:** Result is *undetermined*: not a pass. We record it, optionally escalate, and never count it as proven.
**Detailed:** Tiered strategy: short limit → re-run undetermined with stronger engines/longer limit/abstractions/helper assertions/case-splitting. Track undetermined % per block; report bounded-proof depth if available.
**Project:** Mock marks complex properties undetermined; CI reports undetermined count; throughput tracks *conclusive* props/hour.
**Follow-up:** When is a bounded proof acceptable? (When depth exceeds the design's sequential diameter or backed by simulation/cover evidence and sign-off agreement.)

### 15. How do you distinguish a useful corner case from random noise?
**Short:** Reproduce with the same seed, check legality, cluster by signature, and confirm it exercises a meaningful rare bin or assertion.
**Detailed:** Re-run top candidates with new seeds; require stability; cross-check with coverage/assertions; triage TB vs RTL; weight scores by severity; log-compress rare counters; dedupe near-identical failures.
**Project:** `corner_case_score` weights; history-free objective; `docs` §6.2.
**Follow-up:** What if the "corner case" is an illegal stimulus? (Strengthen constraints/assumptions; add the rule to the hard legality filter.)

---
## Senior

### 16. How would you architect this for an enterprise verification farm?
**Short:** Stateless job contract + scheduler + license-aware admission + central telemetry + reproducible tool environments.
**Detailed:** API/queue for jobs; workers on farm nodes with pinned tool containers/modules; license broker that reserves tokens before dispatch; artifact store for logs/waves/coverage; DB for results (property, status, tool version, seed, hash); dashboards/alerts; multi-tenant fair share and priority; secrets & license files outside repos.
**Project:** Clear seams: `Job` → `run_fn` → `FormalResult` → metrics; configs separate vendor knowledge.
**Follow-up:** How do you do fair-share across teams? (Weighted queues with aging; quota per project; preemption of exploratory work.)

### 17. How would you optimize compute/license cost?
**Short:** Raise useful seat-seconds: reduce idle, reduce wasted undetermined/failed runs, and run the right job at the right priority.
**Detailed:** Right-size seats by percentile demand; batch to cut checkout overhead; kill hopeless jobs early (budget by property class); cache and run incrementally; schedule heavy jobs off-peak; use BO to reduce simulations needed; track $/conclusive-result.
**Project:** Utilization & idle-seat-seconds in `metrics.py`; LPT scheduling.
**Follow-up:** How do you justify buying more seats? (Queue-wait cost × engineers' time vs seat price, from p95 wait data.)

### 18. How would you handle heterogeneous EDA tool versions?
**Short:** Version is part of the job identity; adapters and parsers are versioned; results are never compared across versions without labelling.
**Detailed:** Registry of tool entries per version in config; contract tests with golden logs per version; environment modules/containers; pin versions per release; canary runs for upgrades; tag cache keys with version.
**Project:** `tools.yaml` entries and `parsers/` plug-ins; extend `PARSERS` by version key.
**Follow-up:** What if the log format changes silently? (Fixture tests + silent-failure guard + alert on "0 properties parsed".)

### 19. How would you make the framework reproducible?
**Short:** Pin everything that influences results and record it with each result.
**Detailed:** Seed in every job; tool version/hash; RTL commit; config hash; container image digest; clean env whitelist; deterministic ordering; store command line (the wrapper writes `# cmd:` at top of each log); re-run on request from metadata.
**Project:** `build_env` whitelist; seeds propagated; per-run directories.
**Follow-up:** Can formal results differ run to run? (Yes: multithreaded engines and time limits cause variance; fix seeds/threads and compare with tolerance.)

### 20. How would you integrate coverage feedback into Bayesian Optimization?
**Short:** Use coverage as (part of) the objective, keeping the objective stationary, and include a global coverage-closure loop.
**Detailed:** Options: (1) score on a *fixed* set of target (hard) bins; (2) multi-objective BO over (coverage, failures, cost); (3) treat "new vs merged coverage" as non-stationary and re-fit with decay or reset the model when the baseline moves; (4) contextual BO per coverage hole; (5) cluster uncovered bins and run one BO per cluster.
**Project:** Objective is history-free; `CoverageLedger` tracks cumulative coverage separately.
**Follow-up:** How do you prevent BO from over-focusing on one region? (Increase ξ/κ, add diversity penalty, restarts, TuRBO trust regions.)
