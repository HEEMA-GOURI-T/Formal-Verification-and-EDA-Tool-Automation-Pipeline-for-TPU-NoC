// Small example DUT for the illustrative formal flow (not synthesized here).
module sync_fifo #(parameter int DEPTH = 16, parameter int W = 8) (
  input  logic clk, rst_n, wr_en, rd_en,
  input  logic [W-1:0] wdata,
  output logic [W-1:0] rdata,
  output logic full, empty
);
  logic [W-1:0] mem [DEPTH];
  logic [$clog2(DEPTH):0] wptr, rptr;
  assign full  = (wptr - rptr) == DEPTH;
  assign empty = (wptr == rptr);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) begin wptr <= '0; rptr <= '0; end
    else begin
      if (wr_en && !full)  begin mem[wptr[$clog2(DEPTH)-1:0]] <= wdata; wptr <= wptr + 1; end
      if (rd_en && !empty) begin rdata <= mem[rptr[$clog2(DEPTH)-1:0]]; rptr <= rptr + 1; end
    end
endmodule
