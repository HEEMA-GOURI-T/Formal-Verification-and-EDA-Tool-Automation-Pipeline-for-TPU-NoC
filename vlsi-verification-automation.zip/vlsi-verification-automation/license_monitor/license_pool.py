"""Client-side floating-license gate with an event log.

Real floating licenses live on a license server (FlexLM/RLM style); jobs check a
seat out at start and return it at end. This class models that contract locally so
we can (a) throttle our own submissions to the seats we own, (b) record
request/grant/release events for metrics, and (c) guarantee FIFO fairness so a
long queue of cheap jobs cannot starve an expensive one.
Production: keep this gate AND poll the real server (server_poller.py) to reconcile.
"""
import threading
import time
from collections import deque
from typing import Dict, List, Optional


class LicenseTimeout(Exception):
    pass


class LicensePool:
    def __init__(self, seats: Dict[str, int], clock=time.monotonic):
        self.seats = dict(seats)
        self._active = {f: 0 for f in seats}
        self._queues = {f: deque() for f in seats}
        self._cv = threading.Condition()
        self._clock = clock
        self.events: List[dict] = []
        self._t0 = clock()

    def _log(self, kind, feature, job):
        self.events.append({"t": self._clock() - self._t0, "kind": kind, "feature": feature, "job": job})

    def acquire(self, feature: str, job: str, timeout: Optional[float] = None):
        if feature not in self.seats:
            raise KeyError(f"unknown license feature {feature}")
        deadline = None if timeout is None else self._clock() + timeout
        with self._cv:
            self._queues[feature].append(job)
            self._log("request", feature, job)
            while not (self._queues[feature][0] == job and self._active[feature] < self.seats[feature]):
                remaining = None if deadline is None else deadline - self._clock()
                if remaining is not None and remaining <= 0:
                    self._queues[feature].remove(job)
                    self._log("timeout", feature, job)
                    self._cv.notify_all()
                    raise LicenseTimeout(f"{job} waited > {timeout}s for {feature}")
                self._cv.wait(remaining)
            self._queues[feature].popleft()
            self._active[feature] += 1
            self._log("grant", feature, job)
            self._cv.notify_all()

    def release(self, feature: str, job: str):
        with self._cv:
            self._active[feature] -= 1
            self._log("release", feature, job)
            self._cv.notify_all()

    def lease(self, feature, job, timeout=None):
        pool = self

        class _L:
            def __enter__(s):
                pool.acquire(feature, job, timeout)
                return pool

            def __exit__(s, *a):
                pool.release(feature, job)

        return _L()

    def snapshot(self):
        with self._cv:
            return {f: {"seats": self.seats[f], "active": self._active[f], "queued": len(self._queues[f])}
                    for f in self.seats}
