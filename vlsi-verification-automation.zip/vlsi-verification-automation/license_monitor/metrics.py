"""Compute license KPIs from the event log (request/grant/release/timeout)."""
import statistics
from typing import Dict, List


def compute_license_metrics(events: List[dict], seats: Dict[str, int], t_end: float = None) -> Dict[str, dict]:
    out = {}
    for feat, n_seats in seats.items():
        ev = sorted((e for e in events if e["feature"] == feat), key=lambda e: e["t"])
        if not ev:
            continue
        t_start = ev[0]["t"]
        t_stop = t_end if t_end is not None else ev[-1]["t"]
        wall = max(t_stop - t_start, 1e-9)
        req, grant, hold_start = {}, {}, {}
        waits, holds = [], []
        active = queued = peak_active = peak_queued = 0
        busy_seat_s = 0.0
        last_t = t_start
        timeouts = 0
        for e in ev:
            busy_seat_s += active * (e["t"] - last_t)
            last_t = e["t"]
            j = e["job"]
            if e["kind"] == "request":
                req[j] = e["t"]; queued += 1
            elif e["kind"] == "grant":
                waits.append(e["t"] - req.get(j, e["t"])); hold_start[j] = e["t"]
                queued -= 1; active += 1
            elif e["kind"] == "release":
                holds.append(e["t"] - hold_start.pop(j, e["t"])); active -= 1
            elif e["kind"] == "timeout":
                queued -= 1; timeouts += 1
            peak_active = max(peak_active, active); peak_queued = max(peak_queued, queued)
        util = busy_seat_s / (n_seats * wall)
        waits_sorted = sorted(waits)
        p95 = waits_sorted[min(len(waits_sorted) - 1, int(0.95 * len(waits_sorted)))] if waits_sorted else 0.0
        out[feat] = {
            "seats": n_seats,
            "requested": sum(1 for e in ev if e["kind"] == "request"),
            "granted": len(waits),
            "timeouts": timeouts,
            "peak_concurrency": peak_active,
            "peak_queue_depth": peak_queued,
            "utilization_pct": round(100 * util, 2),
            "idle_seat_seconds": round(n_seats * wall - busy_seat_s, 3),
            "mean_wait_s": round(statistics.mean(waits), 4) if waits else 0.0,
            "p95_wait_s": round(p95, 4),
            "mean_hold_s": round(statistics.mean(holds), 4) if holds else 0.0,
            "wall_s": round(wall, 3),
        }
    return out


def timeline(events: List[dict], feature: str, step: float = 0.1):
    """(t, active, queued) samples for dashboards."""
    ev = sorted((e for e in events if e["feature"] == feature), key=lambda e: e["t"])
    if not ev:
        return []
    pts, active, queued, i, t = [], 0, 0, 0, ev[0]["t"]
    while t <= ev[-1]["t"] + step:
        while i < len(ev) and ev[i]["t"] <= t:
            k = ev[i]["kind"]
            if k == "request": queued += 1
            elif k == "grant": queued -= 1; active += 1
            elif k == "release": active -= 1
            elif k == "timeout": queued -= 1
            i += 1
        pts.append((round(t, 3), active, queued)); t += step
    return pts
