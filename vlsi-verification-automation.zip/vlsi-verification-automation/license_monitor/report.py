import json
import os
from typing import Dict


def write_reports(metrics: Dict[str, dict], out_dir: str, name: str = "license_report"):
    os.makedirs(out_dir, exist_ok=True)
    jpath = os.path.join(out_dir, f"{name}.json")
    json.dump(metrics, open(jpath, "w"), indent=2)
    cols = ["seats", "requested", "granted", "timeouts", "peak_concurrency", "peak_queue_depth",
            "utilization_pct", "mean_wait_s", "p95_wait_s", "idle_seat_seconds"]
    lines = ["# License report", "", "| feature | " + " | ".join(cols) + " |", "|" + "---|" * (len(cols) + 1)]
    for feat, m in metrics.items():
        lines.append(f"| {feat} | " + " | ".join(str(m[c]) for c in cols) + " |")
    mpath = os.path.join(out_dir, f"{name}.md")
    open(mpath, "w").write("\n".join(lines) + "\n")
    return jpath, mpath
