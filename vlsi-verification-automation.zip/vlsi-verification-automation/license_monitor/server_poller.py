"""Poll the REAL license server and parse its text output.

Vendor syntax is NOT invented here. Set LICENSE_STATUS_COMMAND to whatever your
site uses (a lmstat-like utility for FlexLM, rlmstat for RLM, ...) and implement
`parse_status()` against a captured sample of that output. The mock sample parser
below documents the *shape* of data we need: feature, issued, in_use, queued.
"""
import shlex
import subprocess
import time
from typing import Dict

LICENSE_STATUS_COMMAND = "<vendor-license-status-command>"   # placeholder


def parse_status(text: str) -> Dict[str, dict]:
    """Parse a *sample/mock* format: `FEATURE <name> issued=<n> in_use=<n> queued=<n>`."""
    out = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0] == "FEATURE":
            kv = dict(p.split("=") for p in parts[2:] if "=" in p)
            out[parts[1]] = {k: int(v) for k, v in kv.items()}
    return out


def poll_once(cmd: str = LICENSE_STATUS_COMMAND, timeout: float = 10.0) -> Dict[str, dict]:
    if cmd.startswith("<"):
        raise RuntimeError("LICENSE_STATUS_COMMAND is a placeholder; configure it for your site")
    r = subprocess.run(shlex.split(cmd), capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(f"license status command failed rc={r.returncode}: {r.stderr[:200]}")
    return {"t": time.time(), "features": parse_status(r.stdout)}
