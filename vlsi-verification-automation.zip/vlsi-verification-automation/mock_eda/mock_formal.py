#!/usr/bin/env python3
"""MOCK formal tool. NOT real Cadence/Synopsys behaviour or syntax.

Purpose: give the automation framework something realistic to drive:
startup overhead, elaboration cost (cacheable), per-property solve time,
three outcomes (proven / cex / undetermined), distinct log formats per
"flavor", and injectable failures via env vars:
  MOCK_HANG=1          -> sleeps forever (tests timeout handling)
  MOCK_CRASH=1         -> exits with SIGSEGV-like signal
  MOCK_LICENSE_FAIL=N  -> first N invocations (counted in cache dir) exit rc=3
  MOCK_STARTUP_S, MOCK_ELAB_S -> overhead knobs
Assertion file format: lines like  `name: assert property (...);  // cx=3`
where cx = relative complexity (1..10).
"""
import argparse, hashlib, os, re, signal, sys, time

PROP_RE = re.compile(r"^\s*(\w+)\s*:\s*assert\s+property\b.*?(?://\s*cx=(\d+))?\s*$")


def h(s):
    return int(hashlib.sha256(s.encode()).hexdigest()[:8], 16)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--flavor", required=True, choices=["cadence", "synopsys"])
    ap.add_argument("--design", required=True)
    ap.add_argument("--assertions", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--cache-dir", default="")
    a = ap.parse_args()

    startup = float(os.environ.get("MOCK_STARTUP_S", "0.05"))
    elab = float(os.environ.get("MOCK_ELAB_S", "0.08"))
    tag = "JG" if a.flavor == "cadence" else "VCF"

    # injectable failures
    if a.cache_dir:
        os.makedirs(a.cache_dir, exist_ok=True)
    lic_fail = int(os.environ.get("MOCK_LICENSE_FAIL", "0"))
    if lic_fail and a.cache_dir:
        ctr = os.path.join(a.cache_dir, ".license_fail_counter")
        n = int(open(ctr).read()) if os.path.exists(ctr) else 0
        if n < lic_fail:
            open(ctr, "w").write(str(n + 1))
            print(f"[MOCK-{tag}] ERROR: license unavailable for feature (attempt {n+1})")
            sys.exit(3)
    if os.environ.get("MOCK_HANG") == "1":
        print(f"[MOCK-{tag}] session start", flush=True)
        time.sleep(3600)
    if os.environ.get("MOCK_CRASH") == "1":
        print(f"[MOCK-{tag}] about to crash", flush=True)
        os.kill(os.getpid(), signal.SIGSEGV)

    print(f"[MOCK-{tag}] session start design={os.path.basename(a.design)}")
    time.sleep(startup)

    # elaboration with cache: marker keyed by design content hash
    dh = hashlib.sha256(open(a.design, "rb").read()).hexdigest()[:12]
    marker = os.path.join(a.cache_dir, f"elab_{dh}.ok") if a.cache_dir else ""
    if marker and os.path.exists(marker):
        print(f"[MOCK-{tag}] elaboration: CACHE HIT")
    else:
        time.sleep(elab)
        print(f"[MOCK-{tag}] elaboration: done ({elab:.3f}s)")
        if marker:
            open(marker, "w").write("ok")

    props = []
    for line in open(a.assertions):
        m = PROP_RE.match(line)
        if m:
            props.append((m.group(1), int(m.group(2) or 3)))
    counts = {"proven": 0, "cex": 0, "undetermined": 0}
    for name, cx in props:
        t = 0.004 * cx
        time.sleep(t)
        r = h(f"{name}:{a.seed}") % 100
        # deterministic outcome distribution; high-cx properties more often undetermined
        if r < 4:
            st = "cex"
        elif r < 4 + max(0, cx - 4) * 3:
            st = "undetermined"
        else:
            st = "proven"
        counts[st] += 1
        if a.flavor == "cadence":
            word = {"proven": "proven", "cex": "cex", "undetermined": "undetermined"}[st]
            print(f"[MOCK-JG] property {name} : {word} (t={t:.3f}s)")
        else:
            word = {"proven": "Proven", "cex": "Falsified", "undetermined": "Inconclusive"}[st]
            print(f"RESULT {name} = {word} time={t:.3f}")
    if a.flavor == "cadence":
        print(f"[MOCK-JG] summary: proven={counts['proven']} cex={counts['cex']} undetermined={counts['undetermined']}")
    else:
        print(f"SUMMARY total={len(props)} Proven={counts['proven']} Falsified={counts['cex']} Inconclusive={counts['undetermined']}")
    print(f"[MOCK-{tag}] session end")
    sys.exit(0)


if __name__ == "__main__":
    main()
