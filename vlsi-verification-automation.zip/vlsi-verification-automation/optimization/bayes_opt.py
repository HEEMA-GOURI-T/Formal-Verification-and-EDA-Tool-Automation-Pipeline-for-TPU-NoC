"""Constrained Bayesian Optimization (GP surrogate + Expected Improvement x P(feasible)).

Library choices: scikit-learn GaussianProcessRegressor (Matern 5/2 + white noise),
scipy.stats.norm, scipy.stats.qmc. The acquisition code is written out explicitly so
every line is explainable in an interview.
"""
import warnings
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np
from scipy.stats import norm
from sklearn.exceptions import ConvergenceWarning
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, Matern, WhiteKernel


@dataclass
class Evaluation:
    score: float                         # objective to MAXIMIZE
    constraints: Dict[str, float]        # name -> measured value (must be <= limit)
    info: dict = field(default_factory=dict)


@dataclass
class Trial:
    idx: int
    x_unit: np.ndarray
    params: Dict[str, float]
    ev: Evaluation
    feasible: bool
    acq: Optional[float] = None


def make_gp(dim: int, seed: int):
    k = ConstantKernel(1.0, (1e-2, 1e2)) * Matern(length_scale=np.full(dim, 0.3),
                                                   length_scale_bounds=(0.05, 5.0), nu=2.5) \
        + WhiteKernel(1e-3, (1e-6, 1e-1))
    return GaussianProcessRegressor(kernel=k, normalize_y=True, n_restarts_optimizer=1, random_state=seed)


def expected_improvement(mu, sigma, best, xi=0.01):
    """EI for maximization. xi>0 nudges toward exploration."""
    sigma = np.maximum(sigma, 1e-12)
    z = (mu - best - xi) / sigma
    return (mu - best - xi) * norm.cdf(z) + sigma * norm.pdf(z)


class BayesianOptimizer:
    def __init__(self, space, objective: Callable[[Dict[str, float], int], Evaluation],
                 limits: Dict[str, float], n_init=8, batch_size=1, n_candidates=2048, xi=0.01,
                 patience=15, ei_tol=1e-4, target_score=None, seed=0):
        self.space, self.objective, self.limits = space, objective, dict(limits)
        self.n_init, self.q, self.n_cand, self.xi = n_init, batch_size, n_candidates, xi
        self.patience, self.ei_tol, self.target, self.seed = patience, ei_tol, target_score, seed
        self.rng = np.random.default_rng(seed)
        self.trials: List[Trial] = []
        self.stop_reason = ""

    # ---- evaluation + bookkeeping -----------------------------------------------------
    def _evaluate(self, u, acq=None):
        u = self.space.snap(u)
        params = self.space.decode(u)
        ev = self.objective(params, len(self.trials))
        feas = all(ev.constraints.get(k, 0.0) <= lim for k, lim in self.limits.items())
        self.trials.append(Trial(len(self.trials), u, params, ev, feas, acq))
        return self.trials[-1]

    # ---- model fitting ----------------------------------------------------------------
    def _fit(self, X, y_score, y_cons):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ConvergenceWarning)
            gp = make_gp(self.space.dim, self.seed).fit(X, y_score)
            cons = {k: make_gp(self.space.dim, self.seed).fit(X, v) for k, v in y_cons.items()}
        return gp, cons

    # ---- candidate generation ---------------------------------------------------------
    def _candidates(self):
        n_glob = int(self.n_cand * 0.75)
        glob = self.space.sobol(n_glob, seed=int(self.rng.integers(1 << 30)))
        feas_trials = [t for t in self.trials if t.feasible] or self.trials
        top = sorted(feas_trials, key=lambda t: -t.ev.score)[:5]
        local = []
        for t in top:                                   # exploit: perturb around the best points
            local.append(np.clip(t.x_unit + self.rng.normal(0, 0.08, (self.n_cand // 20, self.space.dim)), 0, 1))
        c = np.vstack([glob] + local)
        c = np.array([self.space.snap(u) for u in c])
        c = np.unique(np.round(c, 6), axis=0)
        legal = np.array([self.space.is_legal(self.space.decode(u)) for u in c])
        seen = {tuple(np.round(t.x_unit, 6)) for t in self.trials}
        keep = np.array([tuple(u) not in seen for u in c])
        return c[legal & keep]

    # ---- acquisition ------------------------------------------------------------------
    def _acquire(self, gp, cons, cands, best_feasible):
        mu, sd = gp.predict(cands, return_std=True)
        pof = np.ones(len(cands))
        for k, g in cons.items():
            m, s = g.predict(cands, return_std=True)
            pof *= norm.cdf((self.limits[k] - m) / np.maximum(s, 1e-9))
        if best_feasible is None:       # nothing feasible yet: first find the feasible region
            return pof, mu, sd
        return expected_improvement(mu, sd, best_feasible, self.xi) * pof, mu, sd

    # ---- main loop --------------------------------------------------------------------
    def run(self, budget: int) -> List[Trial]:
        for u in self.space.random_legal(self.n_init, self.rng):          # 1) initial design
            self._evaluate(u)
        stagnant = 0
        while len(self.trials) < budget:
            if self.target is not None and any(t.feasible and t.ev.score >= self.target for t in self.trials):
                self.stop_reason = "target_score_reached"; break
            X = np.array([t.x_unit for t in self.trials])
            y = np.array([t.ev.score for t in self.trials])
            yc = {k: np.array([t.ev.constraints[k] for t in self.trials]) for k in self.limits}
            gp, cons = self._fit(X, y, yc)                                  # 2) train surrogate
            cands = self._candidates()
            if len(cands) == 0:
                self.stop_reason = "no_candidates"; break
            batch_acq = []
            Xf, yf, ycf = X.copy(), y.copy(), {k: v.copy() for k, v in yc.items()}
            for _ in range(min(self.q, budget - len(self.trials))):        # 3) pick batch (kriging believer)
                feas_scores = [t.ev.score for t in self.trials if t.feasible]
                best = max(feas_scores) if feas_scores else None
                a, mu, sd = self._acquire(gp, cons, cands, best)
                i = int(np.argmax(a))
                batch_acq.append((cands[i], float(a[i])))
                if self.q > 1:                                              # fantasize outcome = predicted mean
                    Xf = np.vstack([Xf, cands[i]]); yf = np.append(yf, mu[i])
                    for k, g in cons.items():
                        ycf[k] = np.append(ycf[k], g.predict(cands[i:i + 1])[0])
                    gp, cons = self._fit(Xf, yf, ycf)
                    cands = np.delete(cands, i, axis=0)
                    if len(cands) == 0: break
            for u, a in batch_acq:                                          # 4) run the real evaluations
                self._evaluate(u, a)
            max_acq = max(a for _, a in batch_acq)                         # 5) stopping logic
            stagnant = stagnant + 1 if max_acq < self.ei_tol else 0
            if stagnant >= self.patience:
                self.stop_reason = "ei_converged"; break
        else:
            self.stop_reason = "budget_exhausted"
        return self.trials
