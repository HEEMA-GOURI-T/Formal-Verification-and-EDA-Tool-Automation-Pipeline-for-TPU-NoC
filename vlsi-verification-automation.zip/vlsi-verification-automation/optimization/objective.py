"""Bridge: params -> simulate -> score. Swap `simulate` for a real simulator launcher."""
from optimization.bayes_opt import Evaluation
from simulation.synthetic_dut import simulate
from stimulus.scoring import corner_case_score


def make_objective(simulate_fn=simulate):
    def objective(params, seed):
        m = simulate_fn(params, seed=seed)
        s = corner_case_score(m)
        return Evaluation(score=s.total,
                          constraints={"sim_cost": m.sim_cost, "memory_mb": m.memory_mb},
                          info={"breakdown": s.__dict__, "overflow": m.overflow_count,
                                "starvation": m.starvation_events, "bins": sorted(m.bins)})
    return objective
