"""BO vs constrained-random on the synthetic DUT.  `python -m optimization.run_demo`
Reports MEASURED numbers from this synthetic setup. They are not hardware results and
must not be quoted as such."""
import json
import os
import statistics
import sys
import time

import numpy as np

from optimization.bayes_opt import BayesianOptimizer
from optimization.objective import make_objective
from stimulus.generators import ConstrainedRandom
from stimulus.scoring import CoverageLedger
from stimulus.space import SearchSpace
from simulation.synthetic_dut import simulate

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_random(space, obj, limits, budget, seed):
    gen = ConstrainedRandom(space, seed)
    best, first_fail, hits = -1, None, 0
    ledger = CoverageLedger()
    scores = []
    for i, u in enumerate(gen.next(budget)):
        ev = obj(space.decode(u), i)
        ok = all(ev.constraints[k] <= v for k, v in limits.items())
        if ok:
            best = max(best, ev.score)
        scores.append(best)
        hits += ev.info["overflow"] > 0 and ok
        if first_fail is None and ev.info["overflow"] > 0 and ok:
            first_fail = i + 1
    return dict(best=best, first_fail=first_fail, hits=hits, curve=scores)


def run_bo(space, obj, limits, budget, seed, n_init):
    bo = BayesianOptimizer(space, obj, limits, n_init=n_init, seed=seed, patience=10 ** 6)
    trials = bo.run(budget)
    best, curve, first_fail, hits = -1, [], None, 0
    for t in trials:
        if t.feasible:
            best = max(best, t.ev.score)
        curve.append(best)
        if t.ev.info["overflow"] > 0 and t.feasible:
            hits += 1
            first_fail = first_fail or t.idx + 1
    return dict(best=best, first_fail=first_fail, hits=hits, curve=curve)


def main(seeds=6, budget=60, n_init=10):
    space = SearchSpace.from_yaml(os.path.join(REPO, "configs/bo_search_space.yaml"))
    limits = {"sim_cost": 6.0, "memory_mb": 900.0}
    obj = make_objective(simulate)
    rows = {"random": [], "bayesopt": []}
    t0 = time.time()
    for s in range(seeds):
        rows["random"].append(run_random(space, obj, limits, budget, 100 + s))
        rows["bayesopt"].append(run_bo(space, obj, limits, budget, 100 + s, n_init))
        print(f"seed {s}: random best={rows['random'][-1]['best']:.3f} hits={rows['random'][-1]['hits']} | "
              f"BO best={rows['bayesopt'][-1]['best']:.3f} hits={rows['bayesopt'][-1]['hits']}", flush=True)

    def agg(name):
        r = rows[name]
        ff = [x["first_fail"] if x["first_fail"] else budget + 1 for x in r]   # censored at budget+1
        return dict(median_best=statistics.median(x["best"] for x in r),
                    mean_hits=statistics.mean(x["hits"] for x in r),
                    median_evals_to_first_failure=statistics.median(ff),
                    runs_finding_failure=sum(1 for x in r if x["first_fail"]), runs=len(r))
    out = {"setup": dict(seeds=seeds, budget=budget, n_init=n_init, limits=limits,
                         note="synthetic DUT; measured here, not hardware data"),
           "random": agg("random"), "bayesopt": agg("bayesopt")}
    rnd, bo = out["random"], out["bayesopt"]
    out["relative"] = {
        "failure_hits_ratio_bo_vs_random": round(bo["mean_hits"] / max(rnd["mean_hits"], 1e-9), 2),
        "evals_to_first_failure_reduction_pct": round(100 * (1 - bo["median_evals_to_first_failure"] /
                                                             rnd["median_evals_to_first_failure"]), 1)}
    os.makedirs(os.path.join(REPO, "reports"), exist_ok=True)
    json.dump({**out, "curves": {k: [r["curve"] for r in v] for k, v in rows.items()}},
              open(os.path.join(REPO, "reports/bo_demo.json"), "w"))
    print(json.dumps(out, indent=2))
    print(f"elapsed {time.time() - t0:.1f}s")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 3.6))
        for name, c in (("random", "tab:gray"), ("bayesopt", "tab:blue")):
            arr = np.array([r["curve"] for r in rows[name]])
            ax.plot(np.median(arr, axis=0), label=name, color=c)
            ax.fill_between(range(arr.shape[1]), arr.min(0), arr.max(0), alpha=0.15, color=c)
        ax.set_xlabel("evaluations"); ax.set_ylabel("best feasible corner-case score"); ax.legend()
        ax.set_title("Synthetic DUT: best-so-far score (median, min-max band)")
        fig.tight_layout(); fig.savefig(os.path.join(REPO, "reports/bo_convergence.png"), dpi=130)
    except Exception as e:
        print("plot skipped:", e)


if __name__ == "__main__":
    main(*(int(a) for a in sys.argv[1:]))
