"""Vendor-specific log parsers behind one interface.

Each parser returns {property_name: status} with status in
{"proven","cex","undetermined"}. Real tool logs differ per vendor/version;
you only rewrite the regexes here - the rest of the framework is unchanged.
"""
import re
from typing import Callable, Dict

VALID = {"proven", "cex", "undetermined"}


class ParseError(Exception):
    pass


_CAD = re.compile(r"^\[MOCK-JG\] property (\w+) : (proven|cex|undetermined)\b")
_SNP = re.compile(r"^RESULT (\w+) = (Proven|Falsified|Inconclusive)\b")
_SNP_MAP = {"Proven": "proven", "Falsified": "cex", "Inconclusive": "undetermined"}


def parse_cadence_mock(text: str) -> Dict[str, str]:
    out = {}
    for line in text.splitlines():
        m = _CAD.match(line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def parse_synopsys_mock(text: str) -> Dict[str, str]:
    out = {}
    for line in text.splitlines():
        m = _SNP.match(line)
        if m:
            out[m.group(1)] = _SNP_MAP[m.group(2)]
    return out


PARSERS: Dict[str, Callable[[str], Dict[str, str]]] = {
    "cadence_mock": parse_cadence_mock,
    "synopsys_mock": parse_synopsys_mock,
}


def parse_log(parser_name: str, text: str) -> Dict[str, str]:
    if parser_name not in PARSERS:
        raise ParseError(f"unknown parser '{parser_name}'")
    return PARSERS[parser_name](text)


def summarize(results: Dict[str, str]) -> Dict[str, int]:
    s = {k: 0 for k in VALID}
    for v in results.values():
        s[v] += 1
    s["total"] = len(results)
    return s
