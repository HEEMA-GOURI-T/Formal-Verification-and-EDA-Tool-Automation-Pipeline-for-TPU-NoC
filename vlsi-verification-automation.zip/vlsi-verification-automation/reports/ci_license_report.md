# License report

| feature | seats | requested | granted | timeouts | peak_concurrency | peak_queue_depth | utilization_pct | mean_wait_s | p95_wait_s | idle_seat_seconds |
|---|---|---|---|---|---|---|---|---|---|---|
| MOCK_FORMAL_CDS | 8 | 4 | 4 | 0 | 4 | 1 | 33.55 | 0.0 | 0.0 | 3.083 |
| MOCK_SIM | 50 | 50 | 50 | 0 | 4 | 1 | 4.3 | 0.0 | 0.0 | 19.7 |
