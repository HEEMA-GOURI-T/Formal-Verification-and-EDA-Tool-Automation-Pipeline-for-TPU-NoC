# CI summary

| stage | status | seconds | detail |
|---|---|---|---|
| validate | PASS | 0.0 | {'tools': ['cadence_mock', 'synopsys_mock']} |
| elaborate | PASS | 0.18 | {'elab_s': 0.172} |
| formal | PASS | 0.58 | {'jobs': 4, 'retries': 0, 'wall_s': 0.58, 'properties': 48} |
| simulate | PASS | 0.42 | {'sims': 50} |
| assertion_analysis | PASS | 0.0 | {'cex': 1, 'baseline': 'created'} |
| coverage | PASS | 0.0 | {'functional_cov_pct': 100.0} |
| license_monitor | PASS | 0.01 | {'MOCK_SIM_peak_concurrency': 4, 'MOCK_SIM_util_pct': 4.3, 'MOCK_SIM_p95_wait_s': 0.0} |
