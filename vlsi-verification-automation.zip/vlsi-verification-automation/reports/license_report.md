# License report

| feature | seats | requested | granted | timeouts | peak_concurrency | peak_queue_depth | utilization_pct | mean_wait_s | p95_wait_s | idle_seat_seconds |
|---|---|---|---|---|---|---|---|---|---|---|
| MOCK_SIM | 20 | 60 | 60 | 0 | 20 | 40 | 80.61 | 0.1312 | 0.3088 | 2.119 |
