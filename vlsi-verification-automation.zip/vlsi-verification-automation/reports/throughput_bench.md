# Throughput benchmark (mock tool)

| variant | wall s | props/hour | cpu util % | jobs | failed |
|---|---|---|---|---|---|
| baseline | 3.31 | 52283 | 12.1 | 48 | 0 |
| +batching | 0.70 | 246187 | 7.48 | 6 | 0 |
| +elab_cache | 0.60 | 286712 | 8.71 | 6 | 0 |
| +lpt_scheduling | 0.55 | 316071 | 10.97 | 6 | 0 |
| optimized(+8wkrs) | 0.63 | 274723 | 4.57 | 6 | 0 |

| metric | before | after | improvement % |
|---|---|---|---|
| assertion_throughput_props_per_hour | 52282.9 | 274722.8 | 425.5 |
| regression_runtime_s | 3.31 | 0.63 | 81.0 |
| conclusive_props_per_hour | 50104.5 | 263276.1 | 425.5 |
| failed_jobs | 0 | 0 | - |
