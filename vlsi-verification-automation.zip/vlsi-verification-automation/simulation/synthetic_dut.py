"""Synthetic stand-in for a simulator run (a tiny cycle-based FIFO + arbiter model).

NOT an RTL simulator. It exists so the optimization loop has a realistic *black box*:
noisy, discontinuous, with rare events that only appear in narrow stimulus regions.
In production this file is replaced by: launch simulator (with the stimulus vector as
plusargs / config file) -> parse functional-coverage + assertion logs -> SimMetrics.
"""
import math
from dataclasses import dataclass, field
from typing import Dict, Set

import numpy as np

DEPTH = 16
STALE = 4            # producer sees occupancy 4 cycles late (the "design bug" window)
ALMOST_FULL = 14


@dataclass
class SimMetrics:
    bins: Set[str] = field(default_factory=set)
    states: Set[tuple] = field(default_factory=set)
    overflow_count: int = 0
    starvation_events: int = 0
    max_occupancy: int = 0
    sim_cost: float = 0.0       # proxy for wall-clock
    memory_mb: float = 0.0      # proxy for peak memory


def resource_model(p: Dict[str, float]):
    cost = 0.5 + 0.08 * p["num_masters"] * math.sqrt(p["burst_len"]) + 2.0 * p["wr_prob"] * (1 + p["hotspot"])
    mem = 100 + 6 * p["burst_len"] * p["num_masters"] + 200 * p["hotspot"]
    return cost, mem


def simulate(p: Dict[str, float], seed: int = 0, cycles: int = 3000) -> SimMetrics:
    rng = np.random.default_rng(seed * 7919 + 13)
    rnd = rng.random(cycles * 4).tolist()
    ri = 0
    burst, gap = int(p["burst_len"]), int(p["idle_gap"])
    masters = int(p["num_masters"])
    m = SimMetrics()
    occ_hist = [0] * STALE
    occ = 0
    phase_left, in_burst = burst, True
    wait = [0] * masters
    full_run = 0
    for _ in range(cycles):
        stale_occ = occ_hist[0]
        wr = False
        if in_burst:
            # arbiter: hotspot biases grant toward master 0
            if rnd[ri] < p["hotspot"]:
                g = 0
            else:
                g = int(rnd[ri + 1] * masters) % masters
            ri += 2
            for k in range(masters):
                if k == g:
                    wait[k] = 0
                else:
                    wait[k] += 1
                    if wait[k] == 140:
                        m.starvation_events += 1
                        m.bins.add("arb_starvation")
            if stale_occ < ALMOST_FULL and rnd[ri] < p["wr_prob"]:
                wr = True
            ri += 1
            phase_left -= 1
            if phase_left <= 0:
                in_burst, phase_left = False, gap
        else:
            phase_left -= 1
            if phase_left <= 0:
                in_burst, phase_left = True, burst
        rd = rnd[ri] >= p["backpressure"]
        ri += 1
        if rd and occ == 0:
            m.bins.add("read_when_empty_stall")
        if wr:
            if occ >= DEPTH and not rd:      # overflow needs a simultaneous read stall
                m.overflow_count += 1
                m.bins.add("OVERFLOW")
            elif occ < DEPTH:
                occ += 1
        if rd and occ > 0:
            occ -= 1
        full_run = full_run + 1 if occ >= DEPTH - 1 else 0
        for k in (2, 4, 8):
            if full_run >= k:
                m.bins.add(f"near_full_run_ge_{k}")
        m.bins.add(f"occ_{occ}")
        m.max_occupancy = max(m.max_occupancy, occ)
        m.states.add((occ, wr, rd, in_burst, min(max(wait), 25) // 5))
        occ_hist = occ_hist[1:] + [occ]
    m.sim_cost, m.memory_mb = resource_model(p)
    return m


ALL_BINS = ([f"occ_{i}" for i in range(DEPTH + 1)] +
            ["near_full_run_ge_2", "near_full_run_ge_4", "near_full_run_ge_8",
             "OVERFLOW", "read_when_empty_stall", "arb_starvation"])
