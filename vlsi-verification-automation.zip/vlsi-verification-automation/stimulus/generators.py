"""Baseline stimulus generators (what BO is compared against)."""
import numpy as np


class ConstrainedRandom:
    """Uniform random over the legal space = classic constrained-random baseline."""
    def __init__(self, space, seed=0):
        self.space, self.rng = space, np.random.default_rng(seed)

    def next(self, n=1):
        return self.space.random_legal(n, self.rng)
