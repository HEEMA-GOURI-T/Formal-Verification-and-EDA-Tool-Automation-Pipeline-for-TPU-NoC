"""Corner-case scoring. History-free on purpose (see docs: keeps the objective stationary
for the GP). Cumulative novelty is tracked separately in `CoverageLedger` for reporting."""
import math
from dataclasses import dataclass
from typing import Dict, Set

from simulation.synthetic_dut import ALL_BINS, SimMetrics

W = dict(cov=0.35, rare=0.20, fail=0.30, states=0.15)
MAX_STATES = 16 * 2 * 2 * 2 * 6      # rough upper bound of the abstract state tuple


@dataclass
class ScoreBreakdown:
    total: float
    cov: float
    rare: float
    fail: float
    states: float


def failure_severity(m: SimMetrics) -> float:
    """0 = clean. Overflow = data-loss class bug (high). Starvation = performance/fairness (medium)."""
    s = 0.0
    if m.overflow_count: s = max(s, 0.6 + 0.4 * min(m.overflow_count, 5) / 5)
    if m.starvation_events: s = max(s, 0.3 + 0.2 * min(m.starvation_events, 5) / 5)
    return s


def corner_case_score(m: SimMetrics) -> ScoreBreakdown:
    cov = len(m.bins & set(ALL_BINS)) / len(ALL_BINS)
    # rare-event density: log-compressed so one runaway counter cannot dominate
    rare_events = m.overflow_count + m.starvation_events + ("near_full_run_ge_8" in m.bins) * 3
    rare = min(1.0, math.log1p(rare_events) / math.log1p(40))
    fail = failure_severity(m)
    states = min(1.0, len(m.states) / MAX_STATES * 3)
    total = W["cov"] * cov + W["rare"] * rare + W["fail"] * fail + W["states"] * states
    return ScoreBreakdown(total, cov, rare, fail, states)


class CoverageLedger:
    """Cumulative coverage across runs (the thing verification managers actually report)."""
    def __init__(self):
        self.bins: Set[str] = set()
        self.first_fail_at = None
        self.n = 0

    def update(self, m: SimMetrics) -> int:
        self.n += 1
        new = len(m.bins - self.bins)
        self.bins |= m.bins
        if self.first_fail_at is None and m.overflow_count > 0:
            self.first_fail_at = self.n
        return new
