"""Search space: typed parameters, unit-cube encoding, legality, sampling."""
import ast
import operator as op
from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import yaml
from scipy.stats import qmc


@dataclass
class Param:
    name: str
    kind: str          # int | float
    low: float
    high: float


_OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
        ast.LtE: op.le, ast.Lt: op.lt, ast.GtE: op.ge, ast.Gt: op.gt, ast.Eq: op.eq, ast.NotEq: op.ne}


def _eval(node, env):
    """Whitelisted evaluator for legality expressions (no eval())."""
    if isinstance(node, ast.Expression): return _eval(node.body, env)
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Name): return env[node.id]
    if isinstance(node, ast.BinOp): return _OPS[type(node.op)](_eval(node.left, env), _eval(node.right, env))
    if isinstance(node, ast.BoolOp):
        vals = [_eval(v, env) for v in node.values]
        return all(vals) if isinstance(node.op, ast.And) else any(vals)
    if isinstance(node, ast.Compare):
        l = _eval(node.left, env)
        for o, c in zip(node.ops, node.comparators):
            r = _eval(c, env)
            if not _OPS[type(o)](l, r): return False
            l = r
        return True
    raise ValueError(f"disallowed expression element {type(node).__name__}")


class SearchSpace:
    def __init__(self, params: List[Param], legal_expr: str = "True"):
        if not params: raise ValueError("empty search space")
        names = [p.name for p in params]
        if len(set(names)) != len(names): raise ValueError("duplicate parameter names")
        for p in params:
            if p.low >= p.high: raise ValueError(f"{p.name}: low must be < high")
            if p.kind not in ("int", "float"): raise ValueError(f"{p.name}: kind must be int|float")
        self.params, self.legal_expr = params, legal_expr
        self._tree = ast.parse(legal_expr, mode="eval")

    @classmethod
    def from_yaml(cls, path):
        raw = yaml.safe_load(open(path))
        ps = [Param(**p) for p in raw["parameters"]]
        return cls(ps, raw.get("constraints", {}).get("legal", "True"))

    @property
    def dim(self): return len(self.params)

    def decode(self, u: np.ndarray) -> Dict[str, float]:
        out = {}
        for x, p in zip(np.clip(u, 0, 1), self.params):
            v = p.low + x * (p.high - p.low)
            out[p.name] = int(round(v)) if p.kind == "int" else float(v)
        return out

    def encode(self, d: Dict[str, float]) -> np.ndarray:
        return np.array([(d[p.name] - p.low) / (p.high - p.low) for p in self.params])

    def snap(self, u: np.ndarray) -> np.ndarray:
        """Project onto representable points (ints rounded) so the GP sees exactly what ran."""
        return self.encode(self.decode(u))

    def is_legal(self, d: Dict[str, float]) -> bool:
        return bool(_eval(self._tree, d))

    def sobol(self, n, seed=0) -> np.ndarray:
        m = max(1, int(np.ceil(np.log2(n))))
        return qmc.Sobol(self.dim, scramble=True, seed=seed).random_base2(m)[:n]

    def random_legal(self, n, rng, max_tries=100000):
        out, tries = [], 0
        while len(out) < n and tries < max_tries:
            u = self.snap(rng.random(self.dim)); tries += 1
            if self.is_legal(self.decode(u)): out.append(u)
        if len(out) < n: raise RuntimeError("could not sample enough legal points; constraints too tight?")
        return np.array(out)
