import os
import dataclasses
import pytest
from wrappers.config import REPO, load_tools_config

DESIGN = os.path.join(REPO, "formal/rtl/sync_fifo.sv")


@pytest.fixture
def cfg():
    return load_tools_config(os.path.join(REPO, "configs/tools.yaml"))


@pytest.fixture
def design():
    return DESIGN


@pytest.fixture
def props_file(tmp_path):
    f = tmp_path / "p.sv"
    f.write_text("".join(f"p{i}: assert property (a |-> b);  // cx={1 + i % 5}\n" for i in range(10)))
    return str(f)


@pytest.fixture
def cache(tmp_path):
    return str(tmp_path / "cache")
