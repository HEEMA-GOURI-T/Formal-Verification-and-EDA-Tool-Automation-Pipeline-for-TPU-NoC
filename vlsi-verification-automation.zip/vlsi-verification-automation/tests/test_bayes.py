import numpy as np
from optimization.bayes_opt import BayesianOptimizer, Evaluation, expected_improvement
from stimulus.space import Param, SearchSpace


def toy_space():
    return SearchSpace([Param("x", "float", 0, 1), Param("y", "float", 0, 1)], "x + y <= 1.6")


def toy_obj(p, seed):
    # peak at (0.3, 0.5) (cost 0.8, feasible); constraint "cost" = x + y must stay <= 1.0
    s = float(np.exp(-((p["x"] - 0.3) ** 2 + (p["y"] - 0.5) ** 2) / 0.1))
    return Evaluation(s, {"cost": p["x"] + p["y"]})


def test_ei_properties():
    mu = np.array([0.0, 1.0]); sd = np.array([1.0, 1.0])
    ei = expected_improvement(mu, sd, best=0.5)
    assert ei[1] > ei[0] > 0                                   # higher mean => higher EI
    assert expected_improvement(np.array([0.0]), np.array([0.0]), 1.0)[0] < 1e-9   # no uncertainty, no gain
    hi_unc = expected_improvement(np.array([0.0]), np.array([2.0]), 0.5)
    lo_unc = expected_improvement(np.array([0.0]), np.array([0.2]), 0.5)
    assert hi_unc > lo_unc                                     # exploration bonus


def test_bo_beats_random_on_toy_and_respects_constraints():
    wins = 0
    for seed in range(4):
        bo = BayesianOptimizer(toy_space(), toy_obj, {"cost": 1.0}, n_init=6, seed=seed, patience=999)
        t = bo.run(24)
        best_bo = max(x.ev.score for x in t if x.feasible)
        rng = np.random.default_rng(seed)
        U = toy_space().random_legal(24, rng)
        best_rnd = max((toy_obj(toy_space().decode(u), 0).score for u in U
                        if toy_obj(toy_space().decode(u), 0).constraints["cost"] <= 1.0), default=0)
        wins += best_bo >= best_rnd
        assert all(x.params["x"] + x.params["y"] <= 1.6 for x in t)          # hard legality
    assert wins >= 3


def test_flat_plateau_is_a_known_failure_mode():
    """Needle-in-haystack objective (score==0 almost everywhere): GP has nothing to learn from.
    This is why the real score is shaped (coverage + rare + severity), not binary pass/fail."""
    needle = lambda p, s: Evaluation(float(abs(p['x'] - 0.123) < 0.01 and abs(p['y'] - 0.77) < 0.01), {'cost': 0.0})
    bo = BayesianOptimizer(toy_space(), needle, {'cost': 1.0}, n_init=6, seed=0, patience=999)
    t = bo.run(30)
    assert max(x.ev.score for x in t) == 0.0   # documented limitation, not a bug


def test_bo_exploits_feasible_region_after_init():
    bo = BayesianOptimizer(toy_space(), toy_obj, {"cost": 1.0}, n_init=6, seed=1, patience=999)
    t = bo.run(24)
    late_feasible = sum(x.feasible for x in t[12:])
    assert late_feasible >= 8                                    # learned the constraint boundary


def test_stops_on_target():
    bo = BayesianOptimizer(toy_space(), toy_obj, {"cost": 1.0}, n_init=6, seed=0, target_score=0.3, patience=999)
    t = bo.run(60)
    assert bo.stop_reason == "target_score_reached" and len(t) < 60


def test_budget_exhausted_reason_and_no_duplicate_points():
    bo = BayesianOptimizer(toy_space(), toy_obj, {"cost": 1.0}, n_init=5, seed=2, patience=999)
    t = bo.run(14)
    assert len(t) == 14 and bo.stop_reason == "budget_exhausted"
    pts = {tuple(np.round(x.x_unit, 6)) for x in t}
    assert len(pts) == len(t)


def test_batch_mode_returns_distinct_points():
    bo = BayesianOptimizer(toy_space(), toy_obj, {"cost": 1.0}, n_init=5, batch_size=3, seed=3, patience=999)
    t = bo.run(14)
    assert len(t) == 14 and len({tuple(np.round(x.x_unit, 6)) for x in t}) == 14


def test_ei_convergence_stop():
    flat = lambda p, s: Evaluation(0.5, {"cost": 0.0})
    bo = BayesianOptimizer(toy_space(), flat, {"cost": 1.0}, n_init=5, seed=0, patience=3, ei_tol=1e-2)
    bo.run(60)
    assert bo.stop_reason == "ei_converged"
