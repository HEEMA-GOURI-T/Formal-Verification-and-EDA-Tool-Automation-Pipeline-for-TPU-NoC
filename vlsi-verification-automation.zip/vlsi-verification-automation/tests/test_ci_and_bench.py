import json, os
import pytest
from benchmarks.metrics import RegressionMetrics, pct_improvement
from ci import run_pipeline as rp


def test_pct_improvement_directions():
    assert pct_improvement(100, 125) == 25.0
    assert pct_improvement(100, 75, higher_is_better=False) == 25.0
    assert pct_improvement(0, 5) != pct_improvement(0, 5)           # NaN guard


def test_metrics_math():
    m = RegressionMetrics("x", wall_s=10, properties_total=100, properties_conclusive=80, jobs=5, jobs_failed=0,
                          retries=0, cpu_s=20, workers=4)
    assert m.throughput_props_per_hour == 3600 * 10 and m.conclusive_per_hour == 3600 * 8
    assert m.cpu_utilization_pct == 50


def test_pipeline_end_to_end_passes_and_writes_reports(tmp_path, monkeypatch):
    monkeypatch.setattr(rp, "BASELINE", str(tmp_path / "base.json"))
    monkeypatch.setattr(rp, "REPORTS", str(tmp_path / "rep"))
    assert rp.main() == 0
    rows = json.load(open(tmp_path / "rep/ci_summary.json"))
    assert [r["stage"] for r in rows][-1] == "license_monitor" and all(r["status"] == "PASS" for r in rows)
    assert os.path.exists(tmp_path / "rep/ci_license_report.md")


def test_pipeline_fails_on_new_counterexample(tmp_path, monkeypatch):
    base = tmp_path / "base.json"; base.write_text("[]")           # baseline says: zero known cex
    monkeypatch.setattr(rp, "BASELINE", str(base)); monkeypatch.setattr(rp, "REPORTS", str(tmp_path / "rep"))
    assert rp.main() == 1
    rows = json.load(open(tmp_path / "rep/ci_summary.json"))
    assert rows[-1]["stage"] == "assertion_analysis" and rows[-1]["status"] == "FAIL"


def test_pipeline_stops_at_first_failed_stage(tmp_path, monkeypatch):
    monkeypatch.setattr(rp, "BASELINE", str(tmp_path / "b.json")); monkeypatch.setattr(rp, "REPORTS", str(tmp_path / "rep"))
    def boom(c): raise rp.Gate("elab broke")
    monkeypatch.setattr(rp, "STAGES", [("validate", rp.st_validate), ("elaborate", boom), ("formal", rp.st_formal)])
    assert rp.main() == 1
    assert [r["stage"] for r in json.load(open(tmp_path / "rep/ci_summary.json"))] == ["validate", "elaborate"]
