import pytest, yaml
from wrappers.config import ConfigError, load_tools_config

BASE = {"tools": {"t": {"vendor": "x", "parser": "cadence_mock",
                        "cmd_template": ["x", "{design}", "{assertions}"]}}}


def write(tmp_path, d):
    p = tmp_path / "c.yaml"; p.write_text(yaml.safe_dump(d)); return str(p)


def test_valid_repo_config(cfg):
    assert {"cadence_mock", "synopsys_mock"} <= set(cfg.tools)
    assert cfg.tools["cadence_mock"].returncode_map[3] == "LICENSE_UNAVAILABLE"


def test_minimal_valid(tmp_path):
    assert "t" in load_tools_config(write(tmp_path, BASE)).tools


@pytest.mark.parametrize("mutate,msg", [
    (lambda d: d["tools"]["t"].pop("parser"), "missing required key 'parser'"),
    (lambda d: d["tools"]["t"].update(cmd_template="x {design} {assertions}"), "list of strings"),
    (lambda d: d["tools"]["t"].update(cmd_template=["x", "{design}"]), "{assertions}"),
    (lambda d: d["tools"]["t"].update(cmd_template=["x", "{design}", "{assertions}", "{bogus}"]), "unknown placeholder"),
    (lambda d: d.update(tools={}), "non-empty"),
    (lambda d: d.update(defaults={"timeout_s": 0}), "timeout_s"),
])
def test_invalid_configs(tmp_path, mutate, msg):
    import copy
    d = copy.deepcopy(BASE); mutate(d)
    with pytest.raises(ConfigError, match=msg.replace("{", r"\{").replace("}", r"\}")):
        load_tools_config(write(tmp_path, d))


def test_missing_and_bad_yaml(tmp_path):
    with pytest.raises(ConfigError, match="not found"):
        load_tools_config(str(tmp_path / "nope.yaml"))
    p = tmp_path / "bad.yaml"; p.write_text("a: [unclosed")
    with pytest.raises(ConfigError, match="invalid YAML"):
        load_tools_config(str(p))
