import threading, time
import pytest
from license_monitor.license_pool import LicensePool
from wrappers.formal_wrapper import FormalResult, Status, run_formal
from wrappers.job_runner import Job, JobRunner


def mk(status=Status.OK, **kw):
    return FormalResult("cadence_mock", "d", "a", status, 0 if status == Status.OK else 1, 0.01, "",
                        summary={"total": 1, "proven": 1}, **kw)


def jobs(n, **kw):
    return [Job(id=f"j{i}", tool="cadence_mock", design="d", assertions="a", **kw) for i in range(n)]


def test_retries_transient_then_succeeds(cfg):
    calls = {"n": 0}

    def fn(*a, **k):
        calls["n"] += 1
        return mk(Status.LICENSE_UNAVAILABLE) if calls["n"] < 3 else mk()
    r = JobRunner(cfg, max_workers=1, retries=3, backoff_s=0.01, run_fn=fn)
    out = r.run(jobs(1))
    assert out["j0"].ok and out["j0"].attempts == 3 and r.stats.retries == 2


def test_gives_up_after_retries(cfg):
    r = JobRunner(cfg, max_workers=1, retries=2, backoff_s=0.01, run_fn=lambda *a, **k: mk(Status.CRASH))
    out = r.run(jobs(1))
    assert out["j0"].status == Status.CRASH and out["j0"].attempts == 3 and r.stats.failed == 1


def test_timeout_not_retried_by_default(cfg):
    n = [0]
    def fn(*a, **k): n[0] += 1; return mk(Status.TIMEOUT)
    JobRunner(cfg, max_workers=1, retries=3, backoff_s=0.01, run_fn=fn).run(jobs(1))
    assert n[0] == 1                       # deterministic failure: retrying wastes licenses


def test_wrapper_exception_isolated_per_job(cfg):
    def fn(tool, d, a, c, t, **k):
        if k["seed"] == 13: raise RuntimeError("boom")
        return mk()
    js = [Job(id=f"j{i}", tool="cadence_mock", design="d", assertions="a", seed=i + 10) for i in range(5)]
    r = JobRunner(cfg, max_workers=3, retries=0, run_fn=fn); out = r.run(js)
    assert out["j3"].status == Status.LAUNCH_ERROR and sum(x.ok for x in out.values()) == 4


def test_max_concurrency_respected(cfg):
    live = [0]; peak = [0]; lock = threading.Lock()
    def fn(*a, **k):
        with lock: live[0] += 1; peak[0] = max(peak[0], live[0])
        time.sleep(0.03)
        with lock: live[0] -= 1
        return mk()
    JobRunner(cfg, max_workers=4, run_fn=fn).run(jobs(24))
    assert peak[0] == 4


def test_license_pool_throttles_below_worker_count(cfg):
    pool = LicensePool({"MOCK_FORMAL_CDS": 2}); live = [0]; peak = [0]; lock = threading.Lock()
    def fn(*a, **k):
        with lock: live[0] += 1; peak[0] = max(peak[0], live[0])
        time.sleep(0.03)
        with lock: live[0] -= 1
        return mk()
    JobRunner(cfg, max_workers=10, license_pool=pool, run_fn=fn).run(jobs(12))
    assert peak[0] <= 2 and pool.snapshot()["MOCK_FORMAL_CDS"]["active"] == 0


def test_lpt_ordering_submits_expensive_first(cfg):
    seen = []
    def fn(tool, d, a, c, t, **k): seen.append(a); return mk()
    js = [Job(id=f"j{i}", tool="cadence_mock", design="d", assertions=f"a{c}", est_cost=c) for i, c in enumerate([1, 9, 3])]
    JobRunner(cfg, max_workers=1, run_fn=fn).run(js)
    assert seen == ["a9", "a3", "a1"]


def test_real_wrapper_retry_integration(cfg, design, props_file, cache):
    """End-to-end with the mock binary: first 2 launches fail on license, 3rd succeeds."""
    def fn(tool, d, a, c, t, **k):
        return run_formal(tool, d, a, c, t, cache_dir=cache, extra_env={"MOCK_LICENSE_FAIL": "2"}, seed=k["seed"])
    r = JobRunner(cfg, max_workers=1, retries=3, backoff_s=0.01, run_fn=fn)
    out = r.run([Job(id="x", tool="cadence_mock", design=design, assertions=props_file)])
    assert out["x"].ok and out["x"].attempts == 3
