import threading, time
import pytest
from license_monitor.license_pool import LicensePool, LicenseTimeout
from license_monitor.metrics import compute_license_metrics, timeline
from license_monitor.server_poller import parse_status, poll_once


def test_never_exceeds_seats_under_contention():
    pool = LicensePool({"F": 3}); live = [0]; peak = [0]; lock = threading.Lock()

    def job(i):
        with pool.lease("F", f"j{i}"):
            with lock: live[0] += 1; peak[0] = max(peak[0], live[0])
            time.sleep(0.02)
            with lock: live[0] -= 1
    ts = [threading.Thread(target=job, args=(i,)) for i in range(20)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert peak[0] <= 3 and pool.snapshot()["F"]["active"] == 0


def test_fifo_fairness_no_starvation():
    pool = LicensePool({"F": 1}); order = []
    pool.acquire("F", "holder")

    def waiter(n):
        pool.acquire("F", n); order.append(n); pool.release("F", n)
    ts = []
    for n in ["a", "b", "c", "d"]:
        t = threading.Thread(target=waiter, args=(n,)); t.start(); ts.append(t); time.sleep(0.05)
    pool.release("F", "holder"); [t.join() for t in ts]
    assert order == ["a", "b", "c", "d"]


def test_timeout_removes_waiter_and_does_not_block_others():
    pool = LicensePool({"F": 1}); pool.acquire("F", "h")
    with pytest.raises(LicenseTimeout):
        pool.acquire("F", "impatient", timeout=0.1)
    got = []
    t = threading.Thread(target=lambda: (pool.acquire("F", "next"), got.append(1)))
    t.start(); time.sleep(0.05); pool.release("F", "h"); t.join(1)
    assert got == [1] and pool.snapshot()["F"]["queued"] == 0


def test_unknown_feature():
    with pytest.raises(KeyError):
        LicensePool({"F": 1}).acquire("G", "j")


def test_metrics_exact_on_handcrafted_events():
    # 2 seats, window 0..10s. j1 holds 0-10 (10 seat-s), j2 requests@2 granted@4 releases@8 (4 seat-s)
    ev = [{"t": 0, "kind": "request", "feature": "F", "job": "j1"}, {"t": 0, "kind": "grant", "feature": "F", "job": "j1"},
          {"t": 2, "kind": "request", "feature": "F", "job": "j2"}, {"t": 4, "kind": "grant", "feature": "F", "job": "j2"},
          {"t": 8, "kind": "release", "feature": "F", "job": "j2"}, {"t": 10, "kind": "release", "feature": "F", "job": "j1"}]
    m = compute_license_metrics(ev, {"F": 2})["F"]
    assert m["utilization_pct"] == 70.0 and m["idle_seat_seconds"] == 6.0
    assert m["peak_concurrency"] == 2 and m["peak_queue_depth"] == 1
    assert m["mean_wait_s"] == 1.0 and m["requested"] == 2 and m["granted"] == 2
    assert max(a for _, a, _ in timeline(ev, "F", 1.0)) == 2


def test_metrics_count_timeouts():
    pool = LicensePool({"F": 1}); pool.acquire("F", "h")
    with pytest.raises(LicenseTimeout): pool.acquire("F", "x", timeout=0.05)
    pool.release("F", "h")
    assert compute_license_metrics(pool.events, pool.seats)["F"]["timeouts"] == 1


def test_poller_parses_sample_and_refuses_placeholder():
    assert parse_status("FEATURE sim issued=50 in_use=12 queued=3\njunk\n") == {"sim": {"issued": 50, "in_use": 12, "queued": 3}}
    with pytest.raises(RuntimeError, match="placeholder"):
        poll_once()
