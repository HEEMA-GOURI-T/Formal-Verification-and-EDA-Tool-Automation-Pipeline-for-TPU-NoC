import pytest
from parsers.formal_log_parser import ParseError, parse_log, summarize
from parsers.formal_log_parser import parse_cadence_mock, parse_synopsys_mock

CAD = "[MOCK-JG] session start\n[MOCK-JG] property a : proven (t=0.01s)\n[MOCK-JG] property b : cex (t=0.01s)\n[MOCK-JG] property c : undetermined (t=0.1s)\n"
SNP = "RESULT a = Proven time=0.1\nRESULT b = Falsified time=0.1\nRESULT c = Inconclusive time=0.3\n"


def test_cadence_and_synopsys_normalize_to_same_vocabulary():
    a, b = parse_cadence_mock(CAD), parse_synopsys_mock(SNP)
    assert a == b == {"a": "proven", "b": "cex", "c": "undetermined"}


def test_summarize():
    assert summarize(parse_log("cadence_mock", CAD)) == {"proven": 1, "cex": 1, "undetermined": 1, "total": 3}


def test_garbage_and_empty_yield_nothing():
    assert parse_cadence_mock("") == {}
    assert parse_synopsys_mock("segfault\nRESULT x = Weird\n") == {}


def test_unknown_parser():
    with pytest.raises(ParseError):
        parse_log("nope", "")
