import dataclasses
from simulation.synthetic_dut import SimMetrics, simulate, resource_model
from stimulus.scoring import CoverageLedger, corner_case_score

QUIET = dict(burst_len=2, idle_gap=20, wr_prob=0.2, backpressure=0.0, num_masters=1, hotspot=0.0)
HOT = dict(burst_len=60, idle_gap=0, wr_prob=0.95, backpressure=0.6, num_masters=2, hotspot=0.9)


def test_simulation_is_reproducible_per_seed():
    a, b = simulate(HOT, 4), simulate(HOT, 4)
    assert (a.bins, a.overflow_count) == (b.bins, b.overflow_count)


def test_aggressive_stimulus_scores_higher_than_quiet():
    assert corner_case_score(simulate(HOT, 1)).total > corner_case_score(simulate(QUIET, 1)).total


def test_score_bounds_and_components():
    s = corner_case_score(simulate(HOT, 2))
    assert 0 <= s.total <= 1 and all(0 <= v <= 1 for v in (s.cov, s.rare, s.fail, s.states))


def test_failure_dominates_ordering():
    clean = SimMetrics(bins={"occ_0"}); bad = SimMetrics(bins={"occ_0"}, overflow_count=3)
    assert corner_case_score(bad).total > corner_case_score(clean).total


def test_rare_term_is_log_compressed():
    a = corner_case_score(SimMetrics(overflow_count=10)).rare
    b = corner_case_score(SimMetrics(overflow_count=10_000)).rare
    assert b <= 1.0 and b - a < 0.6


def test_ledger_tracks_new_bins_and_first_failure():
    led = CoverageLedger()
    assert led.update(SimMetrics(bins={"a", "b"})) == 2
    assert led.update(SimMetrics(bins={"b", "c"}, overflow_count=1)) == 1
    assert led.first_fail_at == 2


def test_resource_model_monotone_in_masters():
    assert resource_model({**QUIET, "num_masters": 8})[1] > resource_model(QUIET)[1]
