import numpy as np
import pytest
from stimulus.space import Param, SearchSpace
from stimulus.generators import ConstrainedRandom
from wrappers.config import REPO
import os

P = os.path.join(REPO, "configs/bo_search_space.yaml")


def test_roundtrip_and_int_rounding():
    sp = SearchSpace.from_yaml(P)
    d = sp.decode(np.array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5]))
    assert isinstance(d["burst_len"], int) and 1 <= d["burst_len"] <= 64
    assert np.allclose(sp.encode(d), sp.snap(sp.encode(d)))


def test_random_legal_samples_are_legal_and_in_bounds():
    sp = SearchSpace.from_yaml(P)
    for u in ConstrainedRandom(sp, 3).next(200):
        d = sp.decode(u)
        assert sp.is_legal(d) and d["burst_len"] * d["num_masters"] <= 160
        assert all(p.low <= d[p.name] <= p.high for p in sp.params)


def test_reproducible_with_seed():
    sp = SearchSpace.from_yaml(P)
    assert np.array_equal(ConstrainedRandom(sp, 9).next(5), ConstrainedRandom(sp, 9).next(5))


def test_sobol_shape_no_warning():
    import warnings
    sp = SearchSpace.from_yaml(P)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        assert sp.sobol(37, seed=1).shape == (37, 6)
    assert not [x for x in w if 'Sobol' in str(x.message)]


@pytest.mark.parametrize("bad", [
    [Param("a", "int", 5, 5)], [Param("a", "str", 0, 1)], [], [Param("a", "int", 0, 1), Param("a", "int", 0, 2)]])
def test_invalid_spaces(bad):
    with pytest.raises(ValueError):
        SearchSpace(bad)


def test_legality_expression_is_sandboxed():
    sp = SearchSpace([Param("a", "int", 0, 10)], "__import__('os').system('echo hi') == 0")
    with pytest.raises(ValueError):
        sp.is_legal({"a": 1})


def test_infeasible_constraints_detected():
    sp = SearchSpace([Param("a", "int", 5, 10)], "a < 1")
    with pytest.raises(RuntimeError):
        sp.random_legal(3, np.random.default_rng(0), max_tries=200)
