import dataclasses, os, sys
import pytest
from wrappers.formal_wrapper import Status, build_command, build_env, run_formal


def with_env(cfg, tool, **env):
    spec = dataclasses.replace(cfg.tools[tool], env={**cfg.tools[tool].env, **env})
    cfg.tools[tool] = spec
    return cfg


@pytest.mark.parametrize("tool", ["cadence_mock", "synopsys_mock"])
def test_ok_path_both_vendors(cfg, design, props_file, cache, tmp_path, tool):
    r = run_formal(tool, design, props_file, cfg, 20, workdir=str(tmp_path / "w"), cache_dir=cache)
    assert r.ok and r.returncode == 0
    assert r.summary["total"] == 10 and set(r.properties.values()) <= {"proven", "cex", "undetermined"}
    assert "# cmd:" in open(r.logfile).read()


def test_deterministic_for_same_seed(cfg, design, props_file, cache):
    a = run_formal("cadence_mock", design, props_file, cfg, 20, seed=5, cache_dir=cache)
    b = run_formal("cadence_mock", design, props_file, cfg, 20, seed=5, cache_dir=cache)
    assert a.properties == b.properties


def test_elaboration_cache_hit_is_faster(cfg, design, props_file, cache):
    cfg = with_env(cfg, "cadence_mock", MOCK_ELAB_S="0.6")
    cold = run_formal("cadence_mock", design, props_file, cfg, 20, cache_dir=cache)
    warm = run_formal("cadence_mock", design, props_file, cfg, 20, cache_dir=cache)
    assert "CACHE HIT" in open(warm.logfile).read()
    assert warm.runtime_s < cold.runtime_s - 0.3


def test_timeout_kills_process_group(cfg, design, props_file, cache):
    r = run_formal("cadence_mock", design, props_file, cfg, 1.0, cache_dir=cache, extra_env={"MOCK_HANG": "1"})
    assert r.status == Status.TIMEOUT and r.returncode is None
    assert r.runtime_s < 6          # killed promptly, not 3600 s


def test_crash_signal_classified(cfg, design, props_file, cache):
    r = run_formal("synopsys_mock", design, props_file, cfg, 10, cache_dir=cache, extra_env={"MOCK_CRASH": "1"})
    assert r.status == Status.CRASH and r.returncode < 0


def test_license_failure_via_returncode_map(cfg, design, props_file, cache):
    r = run_formal("cadence_mock", design, props_file, cfg, 10, cache_dir=cache, extra_env={"MOCK_LICENSE_FAIL": "1"})
    assert r.status == Status.LICENSE_UNAVAILABLE and r.returncode == 3


def test_license_failure_via_log_marker(cfg, design, props_file, cache):
    spec = dataclasses.replace(cfg.tools["cadence_mock"], returncode_map={})   # force the log-marker path
    cfg.tools["cadence_mock"] = spec
    r = run_formal("cadence_mock", design, props_file, cfg, 10, cache_dir=cache, extra_env={"MOCK_LICENSE_FAIL": "1"})
    assert r.status == Status.LICENSE_UNAVAILABLE


def fake_tool(cfg, code, rc_marker=""):
    spec = dataclasses.replace(cfg.tools["cadence_mock"], cmd_template=[sys.executable, "-c", code, "{design}", "{assertions}"],
                               returncode_map={}, license_markers=[])
    cfg.tools["fake"] = spec
    return cfg


def test_rc0_but_unparseable_is_parse_error_not_success(cfg, design, props_file):
    cfg = fake_tool(cfg, "print('tool exited happily but printed nothing useful')")
    r = run_formal("fake", design, props_file, cfg, 10)
    assert r.status == Status.PARSE_ERROR and "silent failure" in r.message


def test_nonzero_exit_is_tool_error(cfg, design, props_file):
    cfg = fake_tool(cfg, "import sys; sys.exit(7)")
    r = run_formal("fake", design, props_file, cfg, 10)
    assert r.status == Status.TOOL_ERROR and r.returncode == 7


def test_missing_executable_is_launch_error(cfg, design, props_file):
    cfg.tools["fake"] = dataclasses.replace(cfg.tools["cadence_mock"], cmd_template=["/no/such/binary", "{design}", "{assertions}"])
    r = run_formal("fake", design, props_file, cfg, 10)
    assert r.status == Status.LAUNCH_ERROR


def test_unknown_tool_raises(cfg, design, props_file):
    with pytest.raises(KeyError):
        run_formal("nope", design, props_file, cfg, 5)


def test_env_is_whitelisted_and_expanded(cfg, monkeypatch):
    monkeypatch.setenv("SECRET_TOKEN", "x"); monkeypatch.setenv("LM_LICENSE_FILE", "27000@lic")
    monkeypatch.setenv("MY_ROOT", "/opt/eda")
    spec = dataclasses.replace(cfg.tools["cadence_mock"], env={"TOOL_HOME": "${MY_ROOT}/bin"})
    env = build_env(spec)
    assert "SECRET_TOKEN" not in env and env["LM_LICENSE_FILE"] == "27000@lic" and env["TOOL_HOME"] == "/opt/eda/bin"


def test_command_is_argv_list_without_shell(cfg):
    cmd = build_command(cfg.tools["cadence_mock"], dict(python="py", repo="/r", design="/d x.sv; rm -rf /",
                                                        assertions="/a", seed=1, cache_dir="/c", workdir="/w"))
    assert isinstance(cmd, list) and "/d x.sv; rm -rf /" in cmd      # stays a single argv element
