"""Config loading + validation (fail early, with precise messages)."""
import os
from dataclasses import dataclass, field
from typing import Dict, List

import yaml

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
KNOWN_PLACEHOLDERS = {"python", "repo", "design", "assertions", "seed", "cache_dir", "workdir"}


class ConfigError(Exception):
    pass


@dataclass
class ToolSpec:
    name: str
    vendor: str
    cmd_template: List[str]
    parser: str
    license_feature: str = ""
    env: Dict[str, str] = field(default_factory=dict)
    returncode_map: Dict[int, str] = field(default_factory=dict)
    license_markers: List[str] = field(default_factory=list)


@dataclass
class ToolsConfig:
    tools: Dict[str, ToolSpec]
    timeout_s: float = 60.0
    workdir_root: str = "logs/runs"


def _validate_template(name, tmpl):
    import re
    if not isinstance(tmpl, list) or not tmpl or not all(isinstance(x, str) for x in tmpl):
        raise ConfigError(f"tool '{name}': cmd_template must be a non-empty list of strings (no shell strings)")
    for tok in tmpl:
        for ph in re.findall(r"\{(\w+)\}", tok):
            if ph not in KNOWN_PLACEHOLDERS:
                raise ConfigError(f"tool '{name}': unknown placeholder {{{ph}}}")
    joined = " ".join(tmpl)
    for required in ("{design}", "{assertions}"):
        if required not in joined:
            raise ConfigError(f"tool '{name}': cmd_template must contain {required}")


def load_tools_config(path: str) -> ToolsConfig:
    try:
        raw = yaml.safe_load(open(path))
    except FileNotFoundError:
        raise ConfigError(f"config not found: {path}")
    except yaml.YAMLError as e:
        raise ConfigError(f"invalid YAML in {path}: {e}")
    if not isinstance(raw, dict) or "tools" not in raw or not raw["tools"]:
        raise ConfigError("config must define a non-empty 'tools' mapping")
    tools = {}
    for name, t in raw["tools"].items():
        for key in ("cmd_template", "parser", "vendor"):
            if key not in t:
                raise ConfigError(f"tool '{name}': missing required key '{key}'")
        _validate_template(name, t["cmd_template"])
        rc_map = {int(k): v for k, v in (t.get("returncode_map") or {}).items()}
        tools[name] = ToolSpec(
            name=name, vendor=t["vendor"], cmd_template=t["cmd_template"], parser=t["parser"],
            license_feature=t.get("license_feature", ""), env={k: str(v) for k, v in (t.get("env") or {}).items()},
            returncode_map=rc_map, license_markers=[m.lower() for m in t.get("license_markers", [])],
        )
    d = raw.get("defaults", {})
    timeout = float(d.get("timeout_s", 60))
    if timeout <= 0:
        raise ConfigError("defaults.timeout_s must be > 0")
    return ToolsConfig(tools=tools, timeout_s=timeout, workdir_root=d.get("workdir_root", "logs/runs"))
