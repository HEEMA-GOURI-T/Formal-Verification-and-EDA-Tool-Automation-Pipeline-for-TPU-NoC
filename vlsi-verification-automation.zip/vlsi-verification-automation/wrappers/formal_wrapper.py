"""Generic formal-tool execution wrapper.

run_formal(tool, design, assertions, config, timeout) -> FormalResult

Design rules:
  * argv list, never a shell string  -> no injection / quoting bugs
  * own process group                -> a timeout kills the tool's children too
  * stdout+stderr go to a per-run log file (never held in memory)
  * every outcome maps to an explicit Status; the wrapper itself never raises
    for tool-side problems, so a regression can keep going
"""
import enum
import hashlib
import os
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

from parsers.formal_log_parser import ParseError, parse_log, summarize
from wrappers.config import REPO, ToolsConfig


class Status(str, enum.Enum):
    OK = "OK"
    TIMEOUT = "TIMEOUT"
    TOOL_ERROR = "TOOL_ERROR"
    LICENSE_UNAVAILABLE = "LICENSE_UNAVAILABLE"
    CRASH = "CRASH"
    PARSE_ERROR = "PARSE_ERROR"
    LAUNCH_ERROR = "LAUNCH_ERROR"


@dataclass
class FormalResult:
    tool: str
    design: str
    assertions: str
    status: Status
    returncode: Optional[int]
    runtime_s: float
    logfile: str
    properties: Dict[str, str] = field(default_factory=dict)
    summary: Dict[str, int] = field(default_factory=dict)
    attempts: int = 1
    message: str = ""

    @property
    def ok(self):
        return self.status == Status.OK


BASE_ENV_KEYS = ("PATH", "HOME", "LANG", "USER", "TMPDIR", "LM_LICENSE_FILE", "SNPSLMD_LICENSE_FILE", "CDS_LIC_FILE")


def build_env(spec, extra=None):
    """Whitelist inherited env (reproducibility) + per-tool env, with ${VAR} expansion."""
    env = {k: os.environ[k] for k in BASE_ENV_KEYS if k in os.environ}
    for k, v in spec.env.items():
        env[k] = os.path.expandvars(v)
    env.update(extra or {})
    return env


def build_command(spec, ctx):
    try:
        return [tok.format(**ctx) for tok in spec.cmd_template]
    except KeyError as e:
        raise ValueError(f"missing placeholder value {e}")


def _kill_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
    except ProcessLookupError:
        pass


def run_formal(tool: str, design: str, assertions: str, config: ToolsConfig,
               timeout: Optional[float] = None, *, seed: int = 0, workdir: Optional[str] = None,
               cache_dir: Optional[str] = None, extra_env: Optional[Dict[str, str]] = None) -> FormalResult:
    spec = config.tools.get(tool)
    if spec is None:
        raise KeyError(f"unknown tool '{tool}' (known: {sorted(config.tools)})")   # programmer error -> raise
    timeout = float(timeout if timeout is not None else config.timeout_s)

    run_id = hashlib.sha1(f"{tool}{design}{assertions}{seed}{time.time_ns()}".encode()).hexdigest()[:10]
    workdir = workdir or os.path.join(REPO, config.workdir_root, f"{tool}_{run_id}")
    os.makedirs(workdir, exist_ok=True)
    cache_dir = cache_dir or os.path.join(REPO, config.workdir_root, "_cache", tool)
    logfile = os.path.join(workdir, "tool.log")

    ctx = dict(python=sys.executable, repo=REPO, design=os.path.abspath(design),
               assertions=os.path.abspath(assertions), seed=seed, cache_dir=cache_dir, workdir=workdir)
    cmd = build_command(spec, ctx)
    env = build_env(spec, extra_env)

    t0 = time.monotonic()
    base = dict(tool=tool, design=design, assertions=assertions, logfile=logfile)
    try:
        with open(logfile, "w") as lf:
            lf.write(f"# cmd: {' '.join(cmd)}\n")
            lf.flush()
            proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT, env=env, cwd=workdir,
                                    start_new_session=True)
            try:
                rc = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                _kill_group(proc)
                return FormalResult(status=Status.TIMEOUT, returncode=None, runtime_s=time.monotonic() - t0,
                                    message=f"killed after {timeout}s", **base)
    except OSError as e:
        return FormalResult(status=Status.LAUNCH_ERROR, returncode=None, runtime_s=time.monotonic() - t0,
                            message=str(e), **base)

    runtime = time.monotonic() - t0
    text = open(logfile, errors="replace").read()

    # --- return-code classification (order matters) ---
    if rc < 0:
        return FormalResult(status=Status.CRASH, returncode=rc, runtime_s=runtime,
                            message=f"terminated by signal {-rc}", **base)
    if rc in spec.returncode_map:
        return FormalResult(status=Status(spec.returncode_map[rc]), returncode=rc, runtime_s=runtime,
                            message="mapped by returncode_map", **base)
    low = text.lower()
    if any(m in low for m in spec.license_markers) and rc != 0:
        return FormalResult(status=Status.LICENSE_UNAVAILABLE, returncode=rc, runtime_s=runtime,
                            message="license marker in log", **base)
    if rc != 0:
        return FormalResult(status=Status.TOOL_ERROR, returncode=rc, runtime_s=runtime,
                            message=f"non-zero exit {rc}", **base)
    try:
        props = parse_log(spec.parser, text)
    except ParseError as e:
        return FormalResult(status=Status.PARSE_ERROR, returncode=rc, runtime_s=runtime, message=str(e), **base)
    if not props:
        return FormalResult(status=Status.PARSE_ERROR, returncode=rc, runtime_s=runtime,
                            message="rc=0 but no property results parsed (silent failure guard)", **base)
    return FormalResult(status=Status.OK, returncode=rc, runtime_s=runtime, properties=props,
                        summary=summarize(props), **base)
