"""Controlled worker pool for formal/simulation jobs.

Why threads (not processes): each job is a *subprocess*; Python threads just wait on
it, release the GIL, and are cheap. The real parallelism is the EDA tool processes.
"""
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Set

from license_monitor.license_pool import LicensePool, LicenseTimeout
from wrappers.formal_wrapper import FormalResult, Status, run_formal

log = logging.getLogger("job_runner")


@dataclass
class Job:
    id: str
    tool: str
    design: str
    assertions: str
    seed: int = 0
    timeout: Optional[float] = None
    est_cost: float = 1.0          # for longest-job-first scheduling
    extra_env: Dict[str, str] = field(default_factory=dict)


@dataclass
class RunnerStats:
    submitted: int = 0
    ok: int = 0
    failed: int = 0
    retries: int = 0
    wall_s: float = 0.0


RETRYABLE_DEFAULT = {Status.LICENSE_UNAVAILABLE, Status.CRASH}


class JobRunner:
    def __init__(self, tools_cfg, max_workers=8, retries=2, backoff_s=0.2, retry_on: Set[Status] = None,
                 license_pool: Optional[LicensePool] = None, license_wait_s: Optional[float] = None,
                 run_fn: Callable = run_formal):
        self.cfg, self.max_workers, self.retries, self.backoff_s = tools_cfg, max_workers, retries, backoff_s
        self.retry_on = set(retry_on) if retry_on is not None else set(RETRYABLE_DEFAULT)
        self.pool, self.license_wait_s, self.run_fn = license_pool, license_wait_s, run_fn
        self.stats = RunnerStats()
        self._stats_lock = __import__("threading").Lock()

    def _run_one(self, job: Job) -> FormalResult:
        spec = self.cfg.tools[job.tool]
        res = None
        for attempt in range(1, self.retries + 2):
            try:
                if self.pool and spec.license_feature:
                    with self.pool.lease(spec.license_feature, f"{job.id}#{attempt}", self.license_wait_s):
                        res = self.run_fn(job.tool, job.design, job.assertions, self.cfg, job.timeout,
                                          seed=job.seed, extra_env=job.extra_env)
                else:
                    res = self.run_fn(job.tool, job.design, job.assertions, self.cfg, job.timeout,
                                      seed=job.seed, extra_env=job.extra_env)
            except LicenseTimeout as e:
                res = FormalResult(job.tool, job.design, job.assertions, Status.LICENSE_UNAVAILABLE, None, 0.0,
                                   "", message=str(e))
            except Exception as e:  # never let one job kill the regression
                log.exception("job %s crashed the wrapper", job.id)
                res = FormalResult(job.tool, job.design, job.assertions, Status.LAUNCH_ERROR, None, 0.0, "",
                                   message=repr(e))
            res.attempts = attempt
            if res.ok or res.status not in self.retry_on or attempt > self.retries:
                break
            with self._stats_lock:
                self.stats.retries += 1
            delay = self.backoff_s * (2 ** (attempt - 1))
            log.warning("job %s attempt %d -> %s; retry in %.2fs", job.id, attempt, res.status.value, delay)
            time.sleep(delay)
        log.info("job %s -> %s in %.2fs (attempts=%d)", job.id, res.status.value, res.runtime_s, res.attempts)
        return res

    def run(self, jobs: List[Job]) -> Dict[str, FormalResult]:
        t0 = time.monotonic()
        ordered = sorted(jobs, key=lambda j: -j.est_cost)       # longest-processing-time first
        results: Dict[str, FormalResult] = {}
        with ThreadPoolExecutor(max_workers=self.max_workers, thread_name_prefix="job") as ex:
            futs = {ex.submit(self._run_one, j): j for j in ordered}
            for f in as_completed(futs):
                results[futs[f].id] = f.result()
        self.stats.submitted = len(jobs)
        self.stats.ok = sum(r.ok for r in results.values())
        self.stats.failed = len(jobs) - self.stats.ok
        self.stats.wall_s = time.monotonic() - t0
        return results
