#!/usr/bin/env bash
# Bash flavour of the wrapper (for sites that prefer shell entry points / queue systems).
# Usage: run_formal.sh <tool-key> <design> <assertions> [timeout_s]
# Contract: exit 0 = parsed OK; 10=timeout 11=license 12=crash 13=tool error 14=no results; 2=usage
# Real tools: replace the `case` command lines with your site's invocation (placeholders below).
set -uo pipefail
[[ $# -ge 3 ]] || { echo "usage: $0 <tool> <design> <assertions> [timeout_s]" >&2; exit 2; }
TOOL=$1; DESIGN=$(realpath "$2"); ASSERTIONS=$(realpath "$3"); TMO=${4:-60}
REPO=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
RUN_DIR="$REPO/logs/runs/${TOOL}_$(date +%s%N)"; mkdir -p "$RUN_DIR"; LOG="$RUN_DIR/tool.log"

# --- environment: start clean, pass only what the tool needs -------------------------------
env_clean=(env -i PATH="$PATH" HOME="$HOME" LANG="${LANG:-C}")
[[ -n "${LM_LICENSE_FILE:-}" ]] && env_clean+=(LM_LICENSE_FILE="$LM_LICENSE_FILE")

case "$TOOL" in
  cadence_mock|synopsys_mock)
    flavor=${TOOL%_mock}
    cmd=(python3 "$REPO/mock_eda/mock_formal.py" --flavor "$flavor" --design "$DESIGN" --assertions "$ASSERTIONS" --cache-dir "$REPO/logs/runs/_cache/$TOOL") ;;
  cadence_real)   cmd=("<cadence-formal-binary>" "<batch-flag>" "<tcl-script-path>") ;;    # placeholder
  synopsys_real)  cmd=("<synopsys-formal-binary>" "<script-flag>" "<tcl-script-path>") ;;  # placeholder
  *) echo "unknown tool $TOOL" >&2; exit 2 ;;
esac

# --- run with hard timeout: TERM at TMO, KILL 5s later -------------------------------------
"${env_clean[@]}" timeout --kill-after=5 "$TMO" "${cmd[@]}" >"$LOG" 2>&1
rc=$?
case $rc in
  124|137) echo "TIMEOUT log=$LOG"; exit 10 ;;
  3)       echo "LICENSE_UNAVAILABLE log=$LOG"; exit 11 ;;
  139|134) echo "CRASH rc=$rc log=$LOG"; exit 12 ;;
  0)       ;;
  *)       echo "TOOL_ERROR rc=$rc log=$LOG"; exit 13 ;;
esac
# rc==0 is necessary, not sufficient: require at least one parsed result line
n=$(grep -Ec '^\[MOCK-JG\] property |^RESULT ' "$LOG" || true)
[[ "$n" -gt 0 ]] || { echo "NO_RESULTS (silent failure) log=$LOG"; exit 14; }
echo "OK properties=$n log=$LOG"
